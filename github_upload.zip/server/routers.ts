import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    login: publicProcedure
      .input(z.object({ username: z.string(), password: z.string() }))
      .mutation(async ({ input, ctx }) => {
        // Basit admin kontrolü - Gerçek uygulamada env'den okunmalı
        if (input.username === "admin" && input.password === "kalpten123") {
          const adminUser = {
            id: 999,
            openId: "admin-static",
            name: "Admin",
            role: "admin",
            email: "admin@kalptenkareler.com",
            createdAt: new Date(),
            lastSignedIn: new Date(),
          };
          
          // Basit bir session simülasyonu için cookie set edelim
          // Not: Bu basit bir örnektir, gerçek auth için JWT veya session store kullanılmalı
          const cookieOptions = getSessionCookieOptions(ctx.req);
          ctx.res.cookie(COOKIE_NAME, JSON.stringify(adminUser), { 
            ...cookieOptions, 
            maxAge: 24 * 60 * 60 * 1000 // 1 gün
          });
          
          return { success: true, user: adminUser };
        }
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Geçersiz kullanıcı adı veya şifre" });
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // CRM Routers
  customers: router({
    // Create a new customer (public - from WhatsApp/form)
    create: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().email().optional(),
        whatsappNumber: z.string().min(10),
        city: z.string().optional(),
        segment: z.enum(["mothers-day", "fathers-day", "newyear", "general"]).default("general"),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          const existingCustomer = await db.getCustomerByPhone(input.whatsappNumber);
          if (existingCustomer) {
            return { success: true, customerId: existingCustomer.id, isNew: false };
          }

          const result = await db.createCustomer({
            name: input.name,
            email: input.email || null,
            whatsappNumber: input.whatsappNumber,
            segment: input.segment,
            notes: input.notes || null,
            source: "website",
            createdAt: new Date(),
            updatedAt: new Date(),
          });

          return { success: true, customerId: (result as any).insertId, isNew: true };
        } catch (error) {
          console.error("Error creating customer:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to create customer" });
        }
      }),

    // Get customer by ID (protected)
    getById: protectedProcedure
      .input(z.object({ customerId: z.number() }))
      .query(async ({ input }) => {
        try {
          const result = await db.getAllCustomers(1, input.customerId - 1);
          return result.length > 0 ? result[0] : null;
        } catch (error) {
          console.error("Error fetching customer:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get all customers (admin only)
    list: protectedProcedure
      .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getAllCustomers(input.limit, input.offset);
        } catch (error) {
          console.error("Error listing customers:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get customers by segment (admin only)
    getBySegment: protectedProcedure
      .input(z.object({ segment: z.string() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getCustomersBySegment(input.segment);
        } catch (error) {
          console.error("Error fetching customers by segment:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Update customer (admin only)
    update: protectedProcedure
      .input(z.object({
        customerId: z.number(),
        data: z.object({
          name: z.string().optional(),
          email: z.string().email().optional(),
          segment: z.enum(["mothers-day", "fathers-day", "newyear", "general"]).optional(),
          notes: z.string().optional(),
        }),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          await db.updateCustomer(input.customerId, input.data);
          return { success: true };
        } catch (error) {
          console.error("Error updating customer:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),
  }),

  orders: router({
    // Create a new order
    create: publicProcedure
      .input(z.object({
        customerId: z.number(),
        productType: z.enum(["canvas", "frame", "digital"]),
        size: z.string(),
        personCount: z.number().optional(),
        price: z.number(),
        campaign: z.string().optional(),
        designNotes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          const finalPrice = input.price;
          const result = await db.createOrder({
            customerId: input.customerId,
            productType: input.productType,
            size: input.size,
            personCount: input.personCount || null,
            price: input.price.toString(),
            discount: "0",
            finalPrice: finalPrice.toString(),
            status: "pending",
            campaign: input.campaign || null,
            designNotes: input.designNotes || null,
            paymentMethod: undefined,
            paymentStatus: "pending",
            estimatedDelivery: null,
            createdAt: new Date(),
            updatedAt: new Date(),
          });

          return { success: true, orderId: (result as any).insertId };
        } catch (error) {
          console.error("Error creating order:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to create order" });
        }
      }),

    // Get orders by customer
    getByCustomer: protectedProcedure
      .input(z.object({ customerId: z.number() }))
      .query(async ({ input }) => {
        try {
          return await db.getOrdersByCustomer(input.customerId);
        } catch (error) {
          console.error("Error fetching orders:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get all orders (admin only)
    list: protectedProcedure
      .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getAllOrders(input.limit, input.offset);
        } catch (error) {
          console.error("Error listing orders:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get orders by status (admin only)
    getByStatus: protectedProcedure
      .input(z.object({ status: z.string() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getOrdersByStatus(input.status);
        } catch (error) {
          console.error("Error fetching orders by status:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get orders by campaign (admin only)
    getByCampaign: protectedProcedure
      .input(z.object({ campaign: z.string() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getOrdersByCampaign(input.campaign);
        } catch (error) {
          console.error("Error fetching orders by campaign:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Update order status (admin only)
    updateStatus: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        status: z.enum(["pending", "designing", "approved", "printing", "shipped", "delivered", "cancelled"]),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          await db.updateOrderStatus(input.orderId, input.status);
          return { success: true };
        } catch (error) {
          console.error("Error updating order status:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),
  }),

  leads: router({
    // Create a new lead
    create: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().email().optional(),
        whatsappNumber: z.string().min(10),
        source: z.string(),
        interestedProduct: z.string().optional(),
        message: z.string().optional(),
        campaign: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          const result = await db.createLead({
            name: input.name,
            email: input.email || null,
            whatsappNumber: input.whatsappNumber,
            source: input.source,
            interestedProduct: input.interestedProduct || null,
            message: input.message || null,
            campaign: input.campaign || null,
            converted: false,
            convertedOrderId: null,
            phone: null,
            createdAt: new Date(),
            updatedAt: new Date(),
          });

          return { success: true, leadId: (result as any).insertId };
        } catch (error) {
          console.error("Error creating lead:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to create lead" });
        }
      }),

    // Get unconverted leads (admin only)
    getUnconverted: protectedProcedure
      .query(async ({ ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getUnconvertedLeads();
        } catch (error) {
          console.error("Error fetching unconverted leads:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get leads by source (admin only)
    getBySource: protectedProcedure
      .input(z.object({ source: z.string() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getLeadsBySource(input.source);
        } catch (error) {
          console.error("Error fetching leads by source:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get all leads (admin only)
    list: protectedProcedure
      .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getAllLeads(input.limit, input.offset);
        } catch (error) {
          console.error("Error listing leads:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Convert lead to customer/order (admin only)
    convert: protectedProcedure
      .input(z.object({ leadId: z.number(), orderId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          await db.convertLead(input.leadId, input.orderId);
          return { success: true };
        } catch (error) {
          console.error("Error converting lead:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),
  }),

  analytics: router({
    // Get analytics by campaign (admin only)
    getByCampaign: protectedProcedure
      .input(z.object({ campaign: z.string() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getAnalyticsByCampaign(input.campaign);
        } catch (error) {
          console.error("Error fetching analytics:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get analytics for date range (admin only)
    getDateRange: protectedProcedure
      .input(z.object({ startDate: z.date(), endDate: z.date() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getAnalyticsDateRange(input.startDate, input.endDate);
        } catch (error) {
          console.error("Error fetching analytics:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Record analytics event (public)
    track: publicProcedure
      .input(z.object({
        event: z.string(),
        campaign: z.string().optional(),
        pageViews: z.number().optional(),
        uniqueVisitors: z.number().optional(),
        leadsGenerated: z.number().optional(),
        ordersCreated: z.number().optional(),
        revenue: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          await db.createAnalyticsRecord({
            event: input.event,
            campaign: input.campaign || null,
            pageViews: input.pageViews || 0,
            uniqueVisitors: input.uniqueVisitors || 0,
            leadsGenerated: input.leadsGenerated || 0,
            ordersCreated: input.ordersCreated || 0,
            revenue: input.revenue ? input.revenue.toString() : "0",
            conversionRate: "0",
            averageOrderValue: "0",
            date: new Date(),
            createdAt: new Date(),
          });
          return { success: true };
        } catch (error) {
          console.error("Error tracking analytics:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),
  }),

  reviews: router({
    // Create a new review (public)
    create: publicProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().email().optional(),
        rating: z.number().min(1).max(5),
        title: z.string().optional(),
        comment: z.string().min(10),
        orderId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        try {
          await db.createReview({
            name: input.name,
            email: input.email || null,
            rating: input.rating,
            title: input.title || null,
            comment: input.comment,
            orderId: input.orderId || null,
            isApproved: false,
            createdAt: new Date(),
            updatedAt: new Date(),
          });
          return { success: true };
        } catch (error) {
          console.error("Error creating review:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get approved reviews (public)
    getApproved: publicProcedure
      .input(z.object({
        limit: z.number().default(10),
        offset: z.number().default(0),
      }))
      .query(async ({ input }) => {
        try {
          return await db.getApprovedReviews(input.limit, input.offset);
        } catch (error) {
          console.error("Error fetching reviews:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get average rating (public)
    getAverageRating: publicProcedure
      .query(async () => {
        try {
          return await db.getAverageRating();
        } catch (error) {
          console.error("Error fetching average rating:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get pending reviews (admin only)
    getPending: protectedProcedure
      .query(async ({ ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getPendingReviews();
        } catch (error) {
          console.error("Error fetching pending reviews:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Approve review (admin only)
    approve: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          await db.approveReview(input.id);
          return { success: true };
        } catch (error) {
          console.error("Error approving review:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Delete review (admin only)
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          await db.deleteReview(input.id);
          return { success: true };
        } catch (error) {
          console.error("Error deleting review:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),
  }),

  segments: router({
    // Add customer to segment (admin only)
    addToSegment: protectedProcedure
      .input(z.object({
        customerId: z.number(),
        segmentType: z.enum(["high-value", "repeat-customer", "mothers-day", "fathers-day", "newyear", "abandoned-cart", "inactive"]),
        score: z.number().default(0),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          await db.addCustomerSegment(input.customerId, input.segmentType, input.score);
          return { success: true };
        } catch (error) {
          console.error("Error adding customer to segment:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get customers in segment (admin only)
    getByType: protectedProcedure
      .input(z.object({ segmentType: z.string() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getCustomersBySegmentType(input.segmentType);
        } catch (error) {
          console.error("Error fetching segment customers:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),

    // Get customer's segments (admin only)
    getCustomerSegments: protectedProcedure
      .input(z.object({ customerId: z.number() }))
      .query(async ({ input, ctx }) => {
        if (ctx.user?.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        try {
          return await db.getCustomerSegments(input.customerId);
        } catch (error) {
          console.error("Error fetching customer segments:", error);
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
