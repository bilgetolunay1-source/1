import { eq, desc, and, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, customers, orders, leads, analytics, customerSegments, reviews, InsertCustomer, InsertOrder, InsertLead } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// CRM Query Helpers

// ===== CUSTOMER QUERIES =====
export async function createCustomer(data: InsertCustomer) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(customers).values(data);
  return result;
}

export async function getCustomerByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(customers).where(eq(customers.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getCustomerByPhone(phone: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(customers).where(eq(customers.whatsappNumber, phone)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllCustomers(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(customers).limit(limit).offset(offset);
}

export async function getCustomersBySegment(segment: string) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(customers).where(eq(customers.segment, segment as any));
}

export async function updateCustomer(id: number, data: Partial<InsertCustomer>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(customers).set(data).where(eq(customers.id, id));
}

// ===== ORDER QUERIES =====
export async function createOrder(data: InsertOrder) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(orders).values(data);
  return result;
}

export async function getOrdersByCustomer(customerId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(orders).where(eq(orders.customerId, customerId));
}

export async function getAllOrders(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(orders).orderBy(desc(orders.createdAt)).limit(limit).offset(offset);
}

export async function getOrdersByStatus(status: string) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(orders).where(eq(orders.status, status as any));
}

export async function getOrdersByCampaign(campaign: string) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(orders).where(eq(orders.campaign, campaign));
}

export async function updateOrderStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(orders).set({ status: status as any }).where(eq(orders.id, id));
}

export async function getTotalOrdersByCustomer(customerId: number) {
  const db = await getDb();
  if (!db) return 0;
  
  const result = await db.select().from(orders).where(eq(orders.customerId, customerId));
  return result.length;
}

// ===== LEAD QUERIES =====
export async function createLead(data: InsertLead) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(leads).values(data);
  return result;
}

export async function getLeadsBySource(source: string) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(leads).where(eq(leads.source, source));
}

export async function getAllLeads(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(leads).orderBy(desc(leads.createdAt)).limit(limit).offset(offset);
}

export async function getUnconvertedLeads() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(leads).where(eq(leads.converted, false));
}

export async function convertLead(leadId: number, orderId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(leads).set({ converted: true, convertedOrderId: orderId }).where(eq(leads.id, leadId));
}

// ===== ANALYTICS QUERIES =====
export async function createAnalyticsRecord(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(analytics).values(data);
  return result;
}

export async function getAnalyticsByCampaign(campaign: string) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(analytics).where(eq(analytics.campaign, campaign)).orderBy(desc(analytics.date));
}

export async function getAnalyticsDateRange(startDate: Date, endDate: Date) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(analytics).where(
    and(
      gte(analytics.date, startDate),
      lte(analytics.date, endDate)
    )
  ).orderBy(desc(analytics.date));
}

// ===== CUSTOMER SEGMENT QUERIES =====
export async function addCustomerSegment(customerId: number, segmentType: string, score = 0) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(customerSegments).values({
    customerId,
    segmentType: segmentType as any,
    score,
  });
  return result;
}

export async function getCustomerSegments(customerId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(customerSegments).where(eq(customerSegments.customerId, customerId));
}

export async function getCustomersBySegmentType(segmentType: string) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(customerSegments).where(eq(customerSegments.segmentType, segmentType as any));
}

// ===== REVIEW QUERIES =====
export async function createReview(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(reviews).values(data);
  return result;
}

export async function getApprovedReviews(limit = 10, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(reviews).where(eq(reviews.isApproved, true)).orderBy(desc(reviews.createdAt)).limit(limit).offset(offset);
}

export async function getPendingReviews() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(reviews).where(eq(reviews.isApproved, false)).orderBy(desc(reviews.createdAt));
}

export async function getReviewsByOrder(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(reviews).where(eq(reviews.orderId, orderId));
}

export async function approveReview(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(reviews).set({ isApproved: true }).where(eq(reviews.id, id));
}

export async function getAverageRating() {
  const db = await getDb();
  if (!db) return 0;
  
  const result = await db.select().from(reviews).where(eq(reviews.isApproved, true));
  if (result.length === 0) return 0;
  
  const sum = result.reduce((acc: number, r: any) => acc + (r.rating || 0), 0);
  return Math.round((sum / result.length) * 10) / 10;
}

export async function deleteReview(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(reviews).where(eq(reviews.id, id));
}
