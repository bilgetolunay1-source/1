import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

function createUserContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "regular-user",
    email: "user@example.com",
    name: "Regular User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("CRM - Customers", () => {
  it("creates a new customer", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    const result = await caller.customers.create({
      name: "Ayşe Kaya",
      email: "ayse@example.com",
      whatsappNumber: "+905551234567",
      segment: "general",
      notes: "Test customer",
    });

    expect(result.success).toBe(true);
    expect(result.isNew).toBe(true);
    expect(result.customerId).toBeDefined();
  });

  it("returns existing customer if phone already exists", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    // Create first customer
    const first = await caller.customers.create({
      name: "Mehmet Yılmaz",
      email: "mehmet@example.com",
      whatsappNumber: "+905552345678",
      segment: "general",
    });

    // Try to create with same phone
    const second = await caller.customers.create({
      name: "Mehmet Yılmaz",
      email: "mehmet2@example.com",
      whatsappNumber: "+905552345678",
      segment: "general",
    });

    expect(second.success).toBe(true);
    expect(second.isNew).toBe(false);
    expect(second.customerId).toBe(first.customerId);
  });

  it("admin can list customers", async () => {
    const adminCtx = createAdminContext();
    const caller = appRouter.createCaller(adminCtx);

    // Create a customer first
    await appRouter.createCaller({} as TrpcContext).customers.create({
      name: "Test Customer",
      whatsappNumber: "+905553456789",
      segment: "general",
    });

    const result = await caller.customers.list({ limit: 10, offset: 0 });

    expect(Array.isArray(result)).toBe(true);
  });

  it("non-admin cannot list customers", async () => {
    const userCtx = createUserContext();
    const caller = appRouter.createCaller(userCtx);

    try {
      await caller.customers.list({ limit: 10, offset: 0 });
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  });
});

describe("CRM - Orders", () => {
  it("creates a new order", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    // Create customer first
    const customer = await caller.customers.create({
      name: "Zeynep Demir",
      whatsappNumber: "+905554567890",
      segment: "general",
    });

    // Create order
    const result = await caller.orders.create({
      customerId: customer.customerId,
      productType: "canvas",
      size: "50x70 cm",
      personCount: 3,
      price: 1800,
      campaign: "mothers-day",
      designNotes: "Aile fotoğrafı",
    });

    expect(result.success).toBe(true);
    expect(result.orderId).toBeDefined();
  });

  it("admin can get orders by status", async () => {
    const adminCtx = createAdminContext();
    const adminCaller = appRouter.createCaller(adminCtx);
    const publicCaller = appRouter.createCaller({} as TrpcContext);

    // Create customer and order
    const customer = await publicCaller.customers.create({
      name: "Fatih Aydın",
      whatsappNumber: "+905555678901",
      segment: "general",
    });

    await publicCaller.orders.create({
      customerId: customer.customerId,
      productType: "frame",
      size: "30x40 cm",
      price: 1500,
      campaign: "fathers-day",
    });

    // Admin gets orders by status
    const result = await adminCaller.orders.getByStatus("pending");

    expect(Array.isArray(result)).toBe(true);
  });

  it("admin can update order status", async () => {
    const adminCtx = createAdminContext();
    const adminCaller = appRouter.createCaller(adminCtx);
    const publicCaller = appRouter.createCaller({} as TrpcContext);

    // Create customer and order
    const customer = await publicCaller.customers.create({
      name: "Hakan Kara",
      whatsappNumber: "+905556789012",
      segment: "general",
    });

    const order = await publicCaller.orders.create({
      customerId: customer.customerId,
      productType: "digital",
      size: "digital",
      price: 500,
    });

    // Update status
    const result = await adminCaller.orders.updateStatus({
      orderId: order.orderId,
      status: "designing",
    });

    expect(result.success).toBe(true);
  });
});

describe("CRM - Leads", () => {
  it("creates a new lead", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    const result = await caller.leads.create({
      name: "Emine Şahin",
      email: "emine@example.com",
      whatsappNumber: "+905557890123",
      source: "instagram",
      interestedProduct: "canvas",
      message: "Aile fotoğrafı için bilgi istiyorum",
    });

    expect(result.success).toBe(true);
    expect(result.leadId).toBeDefined();
  });

  it("admin can get unconverted leads", async () => {
    const adminCtx = createAdminContext();
    const adminCaller = appRouter.createCaller(adminCtx);
    const publicCaller = appRouter.createCaller({} as TrpcContext);

    // Create a lead
    await publicCaller.leads.create({
      name: "Gül Yıldız",
      whatsappNumber: "+905558901234",
      source: "website",
      interestedProduct: "frame",
    });

    // Get unconverted leads
    const result = await adminCaller.leads.getUnconverted();

    expect(Array.isArray(result)).toBe(true);
  });

  it("admin can get leads by source", async () => {
    const adminCtx = createAdminContext();
    const adminCaller = appRouter.createCaller(adminCtx);
    const publicCaller = appRouter.createCaller({} as TrpcContext);

    // Create leads from different sources
    await publicCaller.leads.create({
      name: "Işık Koç",
      whatsappNumber: "+905559012345",
      source: "instagram",
    });

    // Get leads by source
    const result = await adminCaller.leads.getBySource("instagram");

    expect(Array.isArray(result)).toBe(true);
  });

  it("admin can convert lead to order", async () => {
    const adminCtx = createAdminContext();
    const adminCaller = appRouter.createCaller(adminCtx);
    const publicCaller = appRouter.createCaller({} as TrpcContext);

    // Create lead
    const lead = await publicCaller.leads.create({
      name: "Jale Topuz",
      whatsappNumber: "+905550123456",
      source: "referral",
    });

    // Create customer and order
    const customer = await publicCaller.customers.create({
      name: "Jale Topuz",
      whatsappNumber: "+905550123456",
      segment: "general",
    });

    const order = await publicCaller.orders.create({
      customerId: customer.customerId,
      productType: "canvas",
      size: "40x60 cm",
      price: 1700,
    });

    // Convert lead
    const result = await adminCaller.leads.convert({
      leadId: lead.leadId,
      orderId: order.orderId,
    });

    expect(result.success).toBe(true);
  });
});

describe("CRM - Analytics", () => {
  it("tracks analytics event", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    const result = await caller.analytics.track({
      event: "campaign_view",
      campaign: "mothers-day",
      pageViews: 150,
      uniqueVisitors: 120,
      leadsGenerated: 5,
    });

    expect(result.success).toBe(true);
  });

  it("admin can get analytics by campaign", async () => {
    const adminCtx = createAdminContext();
    const adminCaller = appRouter.createCaller(adminCtx);
    const publicCaller = appRouter.createCaller({} as TrpcContext);

    // Track analytics
    await publicCaller.analytics.track({
      event: "campaign_view",
      campaign: "fathers-day",
      pageViews: 200,
      uniqueVisitors: 180,
    });

    // Get analytics
    const result = await adminCaller.analytics.getByCampaign("fathers-day");

    expect(Array.isArray(result)).toBe(true);
  });

  it("admin can get analytics for date range", async () => {
    const adminCtx = createAdminContext();
    const adminCaller = appRouter.createCaller(adminCtx);

    const startDate = new Date("2026-05-01");
    const endDate = new Date("2026-05-31");

    const result = await adminCaller.analytics.getDateRange({
      startDate,
      endDate,
    });

    expect(Array.isArray(result)).toBe(true);
  });
});

describe("CRM - Segments", () => {
  it("admin can add customer to segment", async () => {
    const adminCtx = createAdminContext();
    const adminCaller = appRouter.createCaller(adminCtx);
    const publicCaller = appRouter.createCaller({} as TrpcContext);

    // Create customer
    const customer = await publicCaller.customers.create({
      name: "Kadir Yıldırım",
      whatsappNumber: "+905551234567",
      segment: "general",
    });

    // Add to segment
    const result = await adminCaller.segments.addToSegment({
      customerId: customer.customerId,
      segmentType: "high-value",
      score: 85,
    });

    expect(result.success).toBe(true);
  });

  it("admin can get customers in segment", async () => {
    const adminCtx = createAdminContext();
    const adminCaller = appRouter.createCaller(adminCtx);
    const publicCaller = appRouter.createCaller({} as TrpcContext);

    // Create customer and add to segment
    const customer = await publicCaller.customers.create({
      name: "Leyla Aslan",
      whatsappNumber: "+905552345678",
      segment: "general",
    });

    await adminCaller.segments.addToSegment({
      customerId: customer.customerId,
      segmentType: "mothers-day",
      score: 90,
    });

    // Get customers in segment
    const result = await adminCaller.segments.getByType("mothers-day");

    expect(Array.isArray(result)).toBe(true);
  });

  it("admin can get customer's segments", async () => {
    const adminCtx = createAdminContext();
    const adminCaller = appRouter.createCaller(adminCtx);
    const publicCaller = appRouter.createCaller({} as TrpcContext);

    // Create customer and add to segments
    const customer = await publicCaller.customers.create({
      name: "Murat Öz",
      whatsappNumber: "+905553456789",
      segment: "general",
    });

    await adminCaller.segments.addToSegment({
      customerId: customer.customerId,
      segmentType: "repeat-customer",
      score: 75,
    });

    // Get customer's segments
    const result = await adminCaller.segments.getCustomerSegments({
      customerId: customer.customerId,
    });

    expect(Array.isArray(result)).toBe(true);
  });
});
