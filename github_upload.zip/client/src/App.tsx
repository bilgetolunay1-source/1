import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import AdminDashboard from "./pages/AdminDashboard";
import AdminLogin from "./pages/AdminLogin";
import CustomerProfile from "./pages/CustomerProfile";
import OrderDetail from "./pages/OrderDetail";
import CampaignAnalytics from "./pages/CampaignAnalytics";
import { FloatingWhatsAppButton } from "./components/FloatingWhatsAppButton";
import { NotificationCenter } from "./components/NotificationCenter";
import Analytics from "./pages/Analytics";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/admin"} component={AdminDashboard} />
      <Route path={"/admin/login"} component={AdminLogin} />
      <Route path={"/admin/analytics"} component={CampaignAnalytics} />
      <Route path={"/analytics"} component={Analytics} />
      <Route path={"/profile"} component={CustomerProfile} />
      <Route path={"/order/:orderId"} component={OrderDetail} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <NotificationCenter />
          <FloatingWhatsAppButton />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
