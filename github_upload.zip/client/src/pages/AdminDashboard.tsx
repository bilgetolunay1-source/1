import { useMemo, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  AlertCircle,
  BarChart3,
  CheckCircle2,
  Clock,
  Eye,
  MessageSquare,
  RefreshCw,
  ShoppingCart,
  TrendingUp,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import ReviewManagement from "@/components/ReviewManagement";

type AdminTab = "overview" | "customers" | "orders" | "leads" | "analytics" | "reviews";

const orderStatusLabels: Record<string, string> = {
  pending: "Beklemede",
  designing: "Tasarlanıyor",
  approved: "Onaylandı",
  printing: "Baskıda",
  shipped: "Gönderildi",
  delivered: "Teslim Edildi",
  cancelled: "İptal",
};

const productTypeLabels: Record<string, string> = {
  canvas: "Kanvas",
  frame: "Çerçeveli",
  digital: "Dijital",
};

function formatDate(value: Date | string | null | undefined) {
  if (!value) return "-";
  return new Date(value).toLocaleString("tr-TR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatPrice(value: string | number | null | undefined) {
  const numericValue = typeof value === "string" ? Number.parseFloat(value) : Number(value || 0);
  return `${numericValue.toLocaleString("tr-TR")} ₺`;
}

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>("overview");

  const analyticsStartDate = useMemo(() => {
    const date = new Date();
    date.setDate(date.getDate() - 30);
    return date;
  }, []);

  const analyticsEndDate = useMemo(() => new Date(), []);

  const customersQuery = trpc.customers.list.useQuery({ limit: 100, offset: 0 });
  const ordersQuery = trpc.orders.list.useQuery({ limit: 100, offset: 0 });
  const leadsQuery = trpc.leads.list.useQuery({ limit: 100, offset: 0 });
  const pendingLeadsQuery = trpc.leads.getUnconverted.useQuery();
  const analyticsQuery = trpc.analytics.getDateRange.useQuery({
    startDate: analyticsStartDate,
    endDate: analyticsEndDate,
  });
  const approvedReviewsQuery = trpc.reviews.getApproved.useQuery({ limit: 100, offset: 0 });
  const pendingReviewsQuery = trpc.reviews.getPending.useQuery();
  const averageRatingQuery = trpc.reviews.getAverageRating.useQuery();

  const updateOrderStatusMutation = trpc.orders.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Sipariş durumu güncellendi");
      ordersQuery.refetch();
    },
    onError: () => {
      toast.error("Sipariş durumu güncellenemedi");
    },
  });

  const convertLeadMutation = trpc.leads.convert.useMutation({
    onSuccess: () => {
      toast.success("Lead dönüştürüldü olarak işaretlendi");
      leadsQuery.refetch();
      pendingLeadsQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Lead dönüştürme sırasında hata oluştu");
    },
  });

  const customers = customersQuery.data || [];
  const orders = ordersQuery.data || [];
  const leads = leadsQuery.data || [];
  const pendingLeads = pendingLeadsQuery.data || [];
  const analytics = analyticsQuery.data || [];
  const approvedReviews = approvedReviewsQuery.data || [];
  const pendingReviews = pendingReviewsQuery.data || [];

  const totalRevenue = orders.reduce((sum, order) => {
    const amount = typeof order.finalPrice === "string" ? Number.parseFloat(order.finalPrice) : Number(order.finalPrice || 0);
    return sum + (Number.isFinite(amount) ? amount : 0);
  }, 0);

  const deliveredOrders = orders.filter((order) => order.status === "delivered").length;
  const activeOrders = orders.filter((order) => order.status !== "delivered" && order.status !== "cancelled").length;
  const conversionRate = leads.length > 0 ? Math.round((customers.length / leads.length) * 100) : 0;
  const recentLeads = leads.slice(0, 5);
  const recentOrders = orders.slice(0, 5);
  const latestAnalytics = analytics[0];

  const refreshAll = () => {
    customersQuery.refetch();
    ordersQuery.refetch();
    leadsQuery.refetch();
    pendingLeadsQuery.refetch();
    analyticsQuery.refetch();
    approvedReviewsQuery.refetch();
    pendingReviewsQuery.refetch();
    averageRatingQuery.refetch();
    toast.success("Panel verileri yenilendi");
  };

  const handleConvertLead = (leadId: number) => {
    convertLeadMutation.mutate({ leadId, orderId: 0 });
  };

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4">
        <Card className="p-8 max-w-md text-center space-y-4">
          <AlertCircle className="w-12 h-12 mx-auto text-destructive" />
          <h1 className="text-2xl font-bold">Yetkisiz Erişim</h1>
          <p className="text-muted-foreground">
            Bu sayfaya erişmek için admin girişi yapmanız gerekir.
          </p>
          <Button 
            onClick={() => window.location.href = "/admin/login"}
            className="w-full bg-accent hover:bg-accent/80"
          >
            Giriş Sayfasına Git
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 space-y-8">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 rounded-full bg-accent/10 px-3 py-1 text-sm font-medium text-accent">
              <Eye className="h-4 w-4" />
              Canlı Site Kontrol Paneli
            </div>
            <h1 className="text-4xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
              Admin Kontrol Paneli
            </h1>
            <p className="text-muted-foreground">
              Aktif siteden gelen müşteri, sipariş, lead, yorum ve kampanya verilerini buradan takip edebilirsiniz.
            </p>
          </div>
          <Button onClick={refreshAll} variant="outline" className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Verileri Yenile
          </Button>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-6">
          <Card className="p-5 space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Toplam Müşteri</span>
              <Users className="h-5 w-5 text-accent" />
            </div>
            <p className="text-3xl font-bold">{customers.length}</p>
          </Card>

          <Card className="p-5 space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Toplam Sipariş</span>
              <ShoppingCart className="h-5 w-5 text-rose-500" />
            </div>
            <p className="text-3xl font-bold">{orders.length}</p>
          </Card>

          <Card className="p-5 space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Aktif Sipariş</span>
              <Clock className="h-5 w-5 text-amber-500" />
            </div>
            <p className="text-3xl font-bold">{activeOrders}</p>
          </Card>

          <Card className="p-5 space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Bekleyen Lead</span>
              <TrendingUp className="h-5 w-5 text-blue-500" />
            </div>
            <p className="text-3xl font-bold">{pendingLeads.length}</p>
          </Card>

          <Card className="p-5 space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Toplam Ciro</span>
              <BarChart3 className="h-5 w-5 text-green-600" />
            </div>
            <p className="text-3xl font-bold">{formatPrice(totalRevenue)}</p>
          </Card>

          <Card className="p-5 space-y-2">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Yorum Puanı</span>
              <MessageSquare className="h-5 w-5 text-purple-500" />
            </div>
            <p className="text-3xl font-bold">{averageRatingQuery.data || 0}/5</p>
          </Card>
        </div>

        <div className="flex flex-wrap gap-3 border-b border-border">
          {([
            ["overview", "Genel Bakış"],
            ["customers", "Müşteriler"],
            ["orders", "Siparişler"],
            ["leads", "Leadler"],
            ["analytics", "Analitikler"],
            ["reviews", "Yorumlar"],
          ] as [AdminTab, string][]).map(([tab, label]) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 font-medium transition-colors ${
                activeTab === tab
                  ? "border-b-2 border-accent text-accent"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {activeTab === "overview" && (
          <div className="grid gap-6 xl:grid-cols-2">
            <Card className="p-6 space-y-4">
              <div>
                <h2 className="text-xl font-bold">Son Siparişler</h2>
                <p className="text-sm text-muted-foreground">Aktif siteden gelen en yeni sipariş kayıtları.</p>
              </div>
              <div className="space-y-3">
                {recentOrders.length === 0 && <p className="text-sm text-muted-foreground">Henüz sipariş kaydı yok.</p>}
                {recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center justify-between rounded-lg border border-border p-3">
                    <div>
                      <p className="font-semibold">Sipariş #{order.id}</p>
                      <p className="text-sm text-muted-foreground">
                        {productTypeLabels[order.productType] || order.productType} · Müşteri #{order.customerId}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{formatPrice(order.finalPrice)}</p>
                      <p className="text-xs text-muted-foreground">{formatDate(order.createdAt)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6 space-y-4">
              <div>
                <h2 className="text-xl font-bold">Son Leadler</h2>
                <p className="text-sm text-muted-foreground">Form, newsletter ve kampanya alanlarından gelen son kişiler.</p>
              </div>
              <div className="space-y-3">
                {recentLeads.length === 0 && <p className="text-sm text-muted-foreground">Henüz lead kaydı yok.</p>}
                {recentLeads.map((lead) => (
                  <div key={lead.id} className="flex items-center justify-between rounded-lg border border-border p-3">
                    <div>
                      <p className="font-semibold">{lead.name || "İsimsiz lead"}</p>
                      <p className="text-sm text-muted-foreground">{lead.whatsappNumber || lead.email || "İletişim yok"}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{lead.source || "-"}</p>
                      <p className="text-xs text-muted-foreground">{formatDate(lead.createdAt)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {activeTab === "customers" && (
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary">
                  <tr>
                    <th className="px-6 py-3 text-left font-semibold">Ad</th>
                    <th className="px-6 py-3 text-left font-semibold">E-posta</th>
                    <th className="px-6 py-3 text-left font-semibold">WhatsApp</th>
                    <th className="px-6 py-3 text-left font-semibold">Segment</th>
                    <th className="px-6 py-3 text-left font-semibold">Kayıt Tarihi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {customers.map((customer) => (
                    <tr key={customer.id} className="hover:bg-secondary/50">
                      <td className="px-6 py-3 font-medium">{customer.name}</td>
                      <td className="px-6 py-3 text-muted-foreground">{customer.email || "-"}</td>
                      <td className="px-6 py-3">{customer.whatsappNumber}</td>
                      <td className="px-6 py-3">
                        <span className="rounded bg-accent/10 px-2 py-1 text-xs font-medium text-accent">
                          {customer.segment || "general"}
                        </span>
                      </td>
                      <td className="px-6 py-3 text-xs text-muted-foreground">{formatDate(customer.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {customersQuery.isLoading && <div className="p-8 text-center text-muted-foreground">Yükleniyor...</div>}
            {!customersQuery.isLoading && customers.length === 0 && <div className="p-8 text-center text-muted-foreground">Kayıtlı müşteri bulunamadı.</div>}
          </Card>
        )}

        {activeTab === "orders" && (
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary">
                  <tr>
                    <th className="px-6 py-3 text-left font-semibold">ID</th>
                    <th className="px-6 py-3 text-left font-semibold">Müşteri</th>
                    <th className="px-6 py-3 text-left font-semibold">Ürün</th>
                    <th className="px-6 py-3 text-left font-semibold">Fiyat</th>
                    <th className="px-6 py-3 text-left font-semibold">Durum</th>
                    <th className="px-6 py-3 text-left font-semibold">Tarih</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {orders.map((order) => (
                    <tr key={order.id} className="hover:bg-secondary/50">
                      <td className="px-6 py-3 font-mono text-xs">#{order.id}</td>
                      <td className="px-6 py-3">Müşteri #{order.customerId}</td>
                      <td className="px-6 py-3">{productTypeLabels[order.productType] || order.productType}</td>
                      <td className="px-6 py-3 font-semibold">{formatPrice(order.finalPrice)}</td>
                      <td className="px-6 py-3">
                        <select
                          value={order.status || "pending"}
                          onChange={(event) =>
                            updateOrderStatusMutation.mutate({
                              orderId: order.id,
                              status: event.target.value as "pending" | "designing" | "approved" | "printing" | "shipped" | "delivered" | "cancelled",
                            })
                          }
                          className="rounded border border-border bg-background px-2 py-1 text-xs"
                        >
                          {Object.entries(orderStatusLabels).map(([value, label]) => (
                            <option key={value} value={value}>{label}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-6 py-3 text-xs text-muted-foreground">{formatDate(order.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {ordersQuery.isLoading && <div className="p-8 text-center text-muted-foreground">Yükleniyor...</div>}
            {!ordersQuery.isLoading && orders.length === 0 && <div className="p-8 text-center text-muted-foreground">Sipariş bulunamadı.</div>}
          </Card>
        )}

        {activeTab === "leads" && (
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-secondary">
                  <tr>
                    <th className="px-6 py-3 text-left font-semibold">Ad</th>
                    <th className="px-6 py-3 text-left font-semibold">İletişim</th>
                    <th className="px-6 py-3 text-left font-semibold">Kaynak</th>
                    <th className="px-6 py-3 text-left font-semibold">Ürün/Kampanya</th>
                    <th className="px-6 py-3 text-left font-semibold">Durum</th>
                    <th className="px-6 py-3 text-left font-semibold">Tarih</th>
                    <th className="px-6 py-3 text-left font-semibold">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {leads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-secondary/50">
                      <td className="px-6 py-3 font-medium">{lead.name || "-"}</td>
                      <td className="px-6 py-3">
                        <div>{lead.whatsappNumber || lead.phone || "-"}</div>
                        <div className="text-xs text-muted-foreground">{lead.email || ""}</div>
                      </td>
                      <td className="px-6 py-3">
                        <span className="rounded bg-blue-100 px-2 py-1 text-xs font-medium text-blue-700">
                          {lead.source || "-"}
                        </span>
                      </td>
                      <td className="px-6 py-3 text-muted-foreground">
                        {lead.interestedProduct || lead.campaign || "-"}
                      </td>
                      <td className="px-6 py-3">
                        {lead.converted ? (
                          <span className="inline-flex items-center gap-1 rounded bg-green-100 px-2 py-1 text-xs font-medium text-green-700">
                            <CheckCircle2 className="h-3 w-3" /> Dönüştü
                          </span>
                        ) : (
                          <span className="rounded bg-amber-100 px-2 py-1 text-xs font-medium text-amber-700">Bekliyor</span>
                        )}
                      </td>
                      <td className="px-6 py-3 text-xs text-muted-foreground">{formatDate(lead.createdAt)}</td>
                      <td className="px-6 py-3">
                        {!lead.converted && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleConvertLead(lead.id)}
                            disabled={convertLeadMutation.isPending}
                          >
                            Dönüştü İşaretle
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {leadsQuery.isLoading && <div className="p-8 text-center text-muted-foreground">Yükleniyor...</div>}
            {!leadsQuery.isLoading && leads.length === 0 && <div className="p-8 text-center text-muted-foreground">Lead bulunamadı.</div>}
          </Card>
        )}

        {activeTab === "analytics" && (
          <div className="grid gap-6 lg:grid-cols-3">
            <Card className="p-6 space-y-2">
              <p className="text-sm text-muted-foreground">Son 30 Gün Sayfa Görüntüleme</p>
              <p className="text-3xl font-bold">{latestAnalytics?.pageViews || 0}</p>
            </Card>
            <Card className="p-6 space-y-2">
              <p className="text-sm text-muted-foreground">Son 30 Gün Tekil Ziyaretçi</p>
              <p className="text-3xl font-bold">{latestAnalytics?.uniqueVisitors || 0}</p>
            </Card>
            <Card className="p-6 space-y-2">
              <p className="text-sm text-muted-foreground">Müşteri / Lead Oranı</p>
              <p className="text-3xl font-bold">%{conversionRate}</p>
            </Card>
            <Card className="p-6 space-y-2 lg:col-span-3">
              <h2 className="text-xl font-bold">Canlı Site Özeti</h2>
              <div className="grid gap-4 md:grid-cols-4">
                <div className="rounded-lg border border-border p-4">
                  <p className="text-sm text-muted-foreground">Teslim Edilen Sipariş</p>
                  <p className="text-2xl font-bold">{deliveredOrders}</p>
                </div>
                <div className="rounded-lg border border-border p-4">
                  <p className="text-sm text-muted-foreground">Onaylı Yorum</p>
                  <p className="text-2xl font-bold">{approvedReviews.length}</p>
                </div>
                <div className="rounded-lg border border-border p-4">
                  <p className="text-sm text-muted-foreground">Onay Bekleyen Yorum</p>
                  <p className="text-2xl font-bold">{pendingReviews.length}</p>
                </div>
                <div className="rounded-lg border border-border p-4">
                  <p className="text-sm text-muted-foreground">Toplam Ciro</p>
                  <p className="text-2xl font-bold">{formatPrice(totalRevenue)}</p>
                </div>
              </div>
            </Card>
          </div>
        )}

        {activeTab === "reviews" && <ReviewManagement />}
      </div>
    </div>
  );
}
