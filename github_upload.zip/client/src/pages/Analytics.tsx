import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TrendingUp, Users, ShoppingCart, MessageSquare, Target, Eye } from 'lucide-react';
import { useState } from 'react';
import { trpc } from '@/lib/trpc';

export default function Analytics() {
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'year'>('month');

  // Fetch analytics data - using mock data for now
  // In production, you would fetch from actual endpoints
  const customersQuery = { data: [], isLoading: false };
  const ordersQuery = { data: [], isLoading: false };
  const leadsQuery = { data: [], isLoading: false };
  const reviewsQuery = { data: [], isLoading: false };

  // Mock data for charts
  const visitorsData = [
    { date: '1 May', visitors: 240, pageViews: 420 },
    { date: '2 May', visitors: 321, pageViews: 540 },
    { date: '3 May', visitors: 200, pageViews: 380 },
    { date: '4 May', visitors: 278, pageViews: 510 },
    { date: '5 May', visitors: 189, pageViews: 320 },
  ];

  const orderStatusData = [
    { name: 'Beklemede', value: 12, fill: '#fbbf24' },
    { name: 'Onaylı', value: 28, fill: '#60a5fa' },
    { name: 'Tasarım Hazır', value: 15, fill: '#34d399' },
    { name: 'Kargo Yolda', value: 22, fill: '#818cf8' },
    { name: 'Tamamlandı', value: 45, fill: '#10b981' },
  ];

  const leadSourcesData = [
    { name: 'Website', value: 65, fill: '#3b82f6' },
    { name: 'Instagram', value: 25, fill: '#ec4899' },
    { name: 'WhatsApp', value: 10, fill: '#22c55e' },
  ];

  const campaignData = [
    { name: 'Anneler Günü', conversions: 45, revenue: 67500 },
    { name: 'Babalar Günü', conversions: 38, revenue: 57000 },
    { name: 'Yılbaşı', conversions: 52, revenue: 78000 },
  ];

  // Calculate metrics
  const totalCustomers = customersQuery.data?.length || 0;
  const totalOrders = ordersQuery.data?.length || 0;
  const totalLeads = leadsQuery.data?.length || 0;
  const averageRating = reviewsQuery.data && reviewsQuery.data.length ? 
    (reviewsQuery.data.reduce((sum: number, r: any) => sum + (r.rating || 0), 0) / reviewsQuery.data.length).toFixed(1) : '0';

  const avgOrderValue = totalOrders && ordersQuery.data ? 
    (ordersQuery.data.reduce((sum: number, o: any) => sum + (o.price || 0), 0)) / totalOrders : 0;

  const conversionRate = totalLeads && totalCustomers ? 
    ((totalCustomers / totalLeads) * 100).toFixed(1) : 0;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="space-y-4">
          <h1 className="text-4xl font-bold text-foreground">Analiz Paneli</h1>
          <p className="text-muted-foreground">Sitenizin performansını gerçek zamanlı olarak izleyin</p>
        </div>

        {/* Time Range Selector */}
        <div className="flex gap-2">
          {(['week', 'month', 'year'] as const).map((range) => (
            <Button
              key={range}
              onClick={() => setTimeRange(range)}
              variant={timeRange === range ? 'default' : 'outline'}
              className={timeRange === range ? 'bg-rose-500 hover:bg-rose-600' : ''}
            >
              {range === 'week' ? 'Bu Hafta' : range === 'month' ? 'Bu Ay' : 'Bu Yıl'}
            </Button>
          ))}
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Total Visitors */}
          <Card className="p-6 space-y-3 border-rose-200">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-foreground">Toplam Ziyaretçi</h3>
              <Eye className="w-5 h-5 text-rose-500" />
            </div>
            <p className="text-3xl font-bold text-foreground">1,428</p>
            <p className="text-sm text-green-600">↑ 12% son haftaya göre</p>
          </Card>

          {/* Total Customers */}
          <Card className="p-6 space-y-3 border-blue-200">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-foreground">Müşteriler</h3>
              <Users className="w-5 h-5 text-blue-500" />
            </div>
            <p className="text-3xl font-bold text-foreground">{totalCustomers}</p>
            <p className="text-sm text-green-600">↑ {totalCustomers > 0 ? '8%' : '0%'} son haftaya göre</p>
          </Card>

          {/* Total Orders */}
          <Card className="p-6 space-y-3 border-green-200">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-foreground">Siparişler</h3>
              <ShoppingCart className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-3xl font-bold text-foreground">{totalOrders}</p>
            <p className="text-sm text-muted-foreground">Ort. Değer: ₺{avgOrderValue.toFixed(0)}</p>
          </Card>

          {/* Conversion Rate */}
          <Card className="p-6 space-y-3 border-purple-200">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-foreground">Dönüşüm Oranı</h3>
              <Target className="w-5 h-5 text-purple-500" />
            </div>
            <p className="text-3xl font-bold text-foreground">{conversionRate}%</p>
            <p className="text-sm text-muted-foreground">{totalLeads} lead'den {totalCustomers} müşteri</p>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Visitors Chart */}
          <Card className="p-6 space-y-4 border-border">
            <h3 className="font-bold text-lg text-foreground">Ziyaretçi Trendi</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={visitorsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="visitors" stroke="#f43f5e" name="Ziyaretçiler" />
                <Line type="monotone" dataKey="pageViews" stroke="#3b82f6" name="Sayfa Görüntülemeleri" />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          {/* Order Status Distribution */}
          <Card className="p-6 space-y-4 border-border">
            <h3 className="font-bold text-lg text-foreground">Sipariş Durumu Dağılımı</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={orderStatusData} cx="50%" cy="50%" labelLine={false} label={({ name, value }) => `${name}: ${value}`} dataKey="value">
                  {orderStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Card>

          {/* Lead Sources */}
          <Card className="p-6 space-y-4 border-border">
            <h3 className="font-bold text-lg text-foreground">Lead Kaynakları</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={leadSourcesData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#3b82f6" name="Lead Sayısı" />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          {/* Campaign Performance */}
          <Card className="p-6 space-y-4 border-border">
            <h3 className="font-bold text-lg text-foreground">Kampanya Performansı</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={campaignData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="conversions" fill="#10b981" name="Dönüşümler" />
                <Bar yAxisId="right" dataKey="revenue" fill="#f59e0b" name="Gelir (₺)" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        {/* Detailed Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Customer Metrics */}
          <Card className="p-6 space-y-4 border-border">
            <h3 className="font-bold text-lg text-foreground">Müşteri Metrikleri</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Yeni Müşteriler</span>
                <span className="font-semibold text-foreground">{totalCustomers}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tekrar Satın Alma</span>
                <span className="font-semibold text-foreground">35%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Müşteri Yaşam Değeri</span>
                <span className="font-semibold text-foreground">₺{(avgOrderValue * 2.5).toFixed(0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Ortalama Sipariş Değeri</span>
                <span className="font-semibold text-foreground">₺{avgOrderValue.toFixed(0)}</span>
              </div>
            </div>
          </Card>

          {/* Lead Metrics */}
          <Card className="p-6 space-y-4 border-border">
            <h3 className="font-bold text-lg text-foreground">Lead Metrikleri</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Toplam Lead</span>
                <span className="font-semibold text-foreground">{totalLeads}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Dönüştürülen Lead</span>
                <span className="font-semibold text-foreground">{totalCustomers}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Dönüşüm Oranı</span>
                <span className="font-semibold text-foreground">{conversionRate}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Lead Kalitesi</span>
                <span className="font-semibold text-foreground">Orta</span>
              </div>
            </div>
          </Card>

          {/* Review Metrics */}
          <Card className="p-6 space-y-4 border-border">
            <h3 className="font-bold text-lg text-foreground">Yorum Metrikleri</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Toplam Yorum</span>
                <span className="font-semibold text-foreground">{reviewsQuery.data?.length || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Ortalama Puan</span>
                <span className="font-semibold text-foreground">⭐ {averageRating}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Onaylı Yorumlar</span>
                <span className="font-semibold text-foreground">{reviewsQuery.data?.length || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Memnuniyet Oranı</span>
                <span className="font-semibold text-foreground">94%</span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
