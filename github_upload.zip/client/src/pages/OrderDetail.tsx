import { useParams, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, ArrowLeft, CheckCircle2, Clock, Truck } from "lucide-react";

export default function OrderDetail() {
  const { orderId } = useParams<{ orderId: string }>();
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();

  // Parse orderId
  const id = parseInt(orderId || "0", 10);

  // Queries - Gerçek uygulamada order'ı ID ile sorgulamak gerekir
  // Şimdilik placeholder
  const orderQuery = trpc.orders.getByCustomer.useQuery(
    { customerId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="p-8 max-w-md text-center space-y-4">
          <AlertCircle className="w-12 h-12 mx-auto text-destructive" />
          <h1 className="text-2xl font-bold">Giriş Yapmanız Gerekir</h1>
          <Button onClick={() => setLocation("/")} className="w-full">
            Ana Sayfaya Dön
          </Button>
        </Card>
      </div>
    );
  }

  const order = orderQuery.data?.find((o) => o.id === id);

  if (orderQuery.isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">Yükleniyor...</p>
        </Card>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="p-8 max-w-md text-center space-y-4">
          <AlertCircle className="w-12 h-12 mx-auto text-destructive" />
          <h1 className="text-2xl font-bold">Sipariş Bulunamadı</h1>
          <Button onClick={() => setLocation("/profile")} className="w-full">
            Profil Sayfasına Dön
          </Button>
        </Card>
      </div>
    );
  }

  // Status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-700";
      case "designing":
        return "bg-blue-100 text-blue-700";
      case "approved":
        return "bg-purple-100 text-purple-700";
      case "printing":
        return "bg-orange-100 text-orange-700";
      case "shipped":
        return "bg-green-100 text-green-700";
      case "delivered":
        return "bg-emerald-100 text-emerald-700";
      case "cancelled":
        return "bg-red-100 text-red-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  // Status timeline
  const statuses = [
    "pending",
    "designing",
    "approved",
    "printing",
    "shipped",
    "delivered",
  ];
  const currentStatusIndex = statuses.indexOf(order.status || "pending");

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 space-y-8">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/profile")}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Geri Dön
          </Button>
          <div>
            <h1 className="text-4xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
              Sipariş #{order.id}
            </h1>
            <p className="text-muted-foreground">
              {new Date(order.createdAt).toLocaleDateString("tr-TR", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </p>
          </div>
        </div>

        {/* Status Badge */}
        <div className="flex items-center gap-4">
          <span className={`px-4 py-2 rounded-full text-sm font-semibold ${getStatusColor(order.status || "pending")}`}>
            {order.status === "pending" && "Beklemede"}
            {order.status === "designing" && "Tasarlanıyor"}
            {order.status === "approved" && "Onaylandı"}
            {order.status === "printing" && "Baskıda"}
            {order.status === "shipped" && "Gönderildi"}
            {order.status === "delivered" && "Teslim Edildi"}
            {order.status === "cancelled" && "İptal"}
          </span>
        </div>

        {/* Status Timeline */}
        <Card className="p-8">
          <h2 className="text-xl font-bold mb-8">Sipariş Durumu</h2>
          <div className="space-y-6">
            {statuses.map((status, index) => (
              <div key={status} className="flex items-start gap-4">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      index <= currentStatusIndex
                        ? "bg-accent text-white"
                        : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    {index <= currentStatusIndex ? (
                      <CheckCircle2 className="w-6 h-6" />
                    ) : (
                      <Clock className="w-6 h-6" />
                    )}
                  </div>
                  {index < statuses.length - 1 && (
                    <div
                      className={`w-1 h-12 ${
                        index < currentStatusIndex ? "bg-accent" : "bg-secondary"
                      }`}
                    />
                  )}
                </div>
                <div className="pt-2">
                  <p className="font-semibold">
                    {status === "pending" && "Sipariş Alındı"}
                    {status === "designing" && "Tasarım Aşaması"}
                    {status === "approved" && "Tasarım Onaylandı"}
                    {status === "printing" && "Baskı Aşaması"}
                    {status === "shipped" && "Kargo Gönderimi"}
                    {status === "delivered" && "Teslim Edildi"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {status === "pending" && "Siparişiniz alınmıştır"}
                    {status === "designing" && "Tasarımınız hazırlanıyor"}
                    {status === "approved" && "Tasarımınız onaylandı"}
                    {status === "printing" && "Ürün baskıya alındı"}
                    {status === "shipped" && "Kargo ile gönderildi"}
                    {status === "delivered" && "Siparişiniz teslim edildi"}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Order Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Product Info */}
          <Card className="p-8 space-y-6">
            <h2 className="text-xl font-bold">Ürün Bilgileri</h2>

            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Ürün Türü:</span>
                <span className="font-semibold">
                  {order.productType === "canvas" && "Kanvas Tablo"}
                  {order.productType === "frame" && "Çerçeveli Fotoğraf"}
                  {order.productType === "digital" && "Dijital Tasarım"}
                </span>
              </div>

              {order.size && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Boyut:</span>
                  <span className="font-semibold">{order.size}</span>
                </div>
              )}

              {order.personCount && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Kişi Sayısı:</span>
                  <span className="font-semibold">{order.personCount}</span>
                </div>
              )}

              {order.campaign && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Kampanya:</span>
                  <span className="font-semibold">{order.campaign}</span>
                </div>
              )}
            </div>
          </Card>

          {/* Pricing Info */}
          <Card className="p-8 space-y-6">
            <h2 className="text-xl font-bold">Fiyat Bilgileri</h2>

            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Birim Fiyat:</span>
                <span className="font-semibold">
                  {typeof order.price === "string"
                    ? parseFloat(order.price).toLocaleString("tr-TR")
                    : Number(order.price || 0).toLocaleString("tr-TR")}{" "}
                  ₺
                </span>
              </div>

              {order.discount && parseFloat(order.discount) > 0 && (
                <div className="flex justify-between text-green-600">
                  <span className="text-muted-foreground">İndirim:</span>
                  <span className="font-semibold">
                    -{parseFloat(order.discount).toLocaleString("tr-TR")} ₺
                  </span>
                </div>
              )}

              <div className="border-t border-border pt-4 flex justify-between">
                <span className="font-semibold">Toplam Fiyat:</span>
                <span className="text-2xl font-bold text-accent">
                  {typeof order.finalPrice === "string"
                    ? parseFloat(order.finalPrice).toLocaleString("tr-TR")
                    : Number(order.finalPrice || 0).toLocaleString("tr-TR")}{" "}
                  ₺
                </span>
              </div>

              {order.paymentStatus && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Ödeme Durumu:</span>
                  <span
                    className={`font-semibold ${
                      order.paymentStatus === "completed"
                        ? "text-green-600"
                        : order.paymentStatus === "failed"
                          ? "text-red-600"
                          : "text-yellow-600"
                    }`}
                  >
                    {order.paymentStatus === "completed" && "Ödendi"}
                    {order.paymentStatus === "pending" && "Beklemede"}
                    {order.paymentStatus === "failed" && "Başarısız"}
                  </span>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Design Notes */}
        {order.designNotes && (
          <Card className="p-8 space-y-4">
            <h2 className="text-xl font-bold">Tasarım Notları</h2>
            <p className="text-muted-foreground whitespace-pre-wrap">
              {order.designNotes}
            </p>
          </Card>
        )}

        {/* Delivery Info */}
        {order.estimatedDelivery && (
          <Card className="p-8 space-y-4 border-l-4 border-accent">
            <div className="flex items-center gap-2">
              <Truck className="w-6 h-6 text-accent" />
              <h2 className="text-xl font-bold">Teslimat Bilgileri</h2>
            </div>
            <p className="text-muted-foreground">
              Tahmini Teslimat Tarihi:{" "}
              <span className="font-semibold text-foreground">
                {new Date(order.estimatedDelivery).toLocaleDateString("tr-TR")}
              </span>
            </p>
            <p className="text-sm text-muted-foreground">
              Türkiye geneline ücretsiz kargo ile gönderilir.
            </p>
          </Card>
        )}

        {/* Action Buttons */}
        <div className="flex gap-4">
          <Button
            onClick={() => setLocation("/profile")}
            variant="outline"
            className="flex-1"
          >
            Diğer Siparişleri Gör
          </Button>
          <Button
            onClick={() => setLocation("/")}
            className="flex-1 bg-accent hover:bg-accent/80"
          >
            Yeni Sipariş Ver
          </Button>
        </div>
      </div>
    </div>
  );
}
