import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { LeadForm } from "@/components/LeadForm";
import ReviewForm from "@/components/ReviewForm";
import ReviewsCarousel from "@/components/ReviewsCarousel";
import { trpc } from "@/lib/trpc";
import { Heart, Instagram, Check, ChevronLeft, ChevronRight, MessageCircle, CheckCircle2, Copy, ShoppingCart, Image, Eye, Printer, Truck, RefreshCw, X } from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { motion } from "framer-motion";

const WHATSAPP_NUMBER = "905469580230";
const IBAN = "TR60 0004 6001 8888 8000 2101 41";
const ACCOUNT_NAME = "Leyla Aslan";

export default function Home() {
  const { user, loading, error, isAuthenticated, logout } = useAuth();
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [showWhatsAppPopup, setShowWhatsAppPopup] = useState(false);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [showPricing, setShowPricing] = useState(false);
  const [activeCampaign, setActiveCampaign] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState<{ [key: string]: string }>({});
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [contactForm, setContactForm] = useState({ name: "", surname: "", phone: "" });

  const approvedReviewsQuery = trpc.reviews.getApproved.useQuery({ limit: 3, offset: 0 });
  const createLeadMutation = trpc.leads.create.useMutation();

  useEffect(() => {
    const calculateTimeLeft = () => {
      const campaignDates: { [key: string]: Date } = {
        "mothers-day": new Date(2026, 4, 10),
        "fathers-day": new Date(2026, 5, 21),
        "newyear": new Date(2026, 11, 31),
      };

      const newTimeLeft: { [key: string]: string } = {};
      Object.entries(campaignDates).forEach(([id, date]) => {
        const difference = date.getTime() - new Date().getTime();
        if (difference > 0) {
          const days = Math.floor(difference / (1000 * 60 * 60 * 24));
          const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
          const minutes = Math.floor((difference / 1000 / 60) % 60);
          newTimeLeft[id] = `${days}g ${hours}s ${minutes}d`;
        } else {
          newTimeLeft[id] = "Kampanya Sona Erdi";
        }
      });
      setTimeLeft(newTimeLeft);
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 60000);
    return () => clearInterval(timer);
  }, []);

  const campaigns = [
    {
      id: "mothers-day",
      title: "Anneler Günü Özel",
      subtitle: "Annelerinize Sevginin Kalıcı Hali",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663622892665/fgZemz5TuDdAEJjBVQMthx/mothers-day-campaign-mJV7jdDTaZNRWU8smXkbSP.webp",
      discount: "%15",
      color: "from-rose-500 to-pink-600",
      bgColor: "bg-rose-50",
      date: "Mayıs 2026",
    },
    {
      id: "fathers-day",
      title: "Babalar Günü Özel",
      subtitle: "Babalarınıza Anıların Gücü",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663622892665/fgZemz5TuDdAEJjBVQMthx/fathers-day-campaign-N3CxvbygZRD2rdWM9mnJYY.webp",
      discount: "%15",
      color: "from-blue-600 to-slate-700",
      bgColor: "bg-slate-50",
      date: "Haziran 2026",
    },
    {
      id: "newyear",
      title: "Yılbaşı Özel",
      subtitle: "Yeni Yıla Yeni Anılarla Başla",
      image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663622892665/fgZemz5TuDdAEJjBVQMthx/newyear-campaign-ZeD7e8UjYjKk263sXHrRDX.webp",
      discount: "%20",
      color: "from-amber-500 to-yellow-600",
      bgColor: "bg-amber-50",
      date: "Aralık 2026",
    },
  ];

  const canvasPricing = [
    {
      title: "1-3 Kişi Birleştirme Dahil",
      badge: "Başlangıç paketi",
      sizes: [
        { label: "20×30 cm", price: "1.400 TL" },
        { label: "30×40 cm", price: "1.500 TL" },
        { label: "35×50 cm", price: "1.600 TL" },
        { label: "40×60 cm", price: "1.700 TL", note: "En çok tercih edilen / Duvar Boyu" },
        { label: "50×70 cm", price: "1.800 TL" },
        { label: "60×90 cm", price: "1.900 TL" },
        { label: "70×90 cm", price: "2.000 TL" },
        { label: "90×120 cm", price: "2.100 TL" },
      ],
    },
    {
      title: "1-5 Kişi Birleştirme Dahil",
      badge: "Aile paketi",
      sizes: [
        { label: "20×30 cm", price: "1.500 TL" },
        { label: "30×40 cm", price: "1.600 TL" },
        { label: "35×50 cm", price: "1.700 TL" },
        { label: "40×60 cm", price: "1.800 TL" },
        { label: "50×70 cm", price: "1.900 TL" },
        { label: "60×90 cm", price: "2.000 TL" },
        { label: "70×100 cm", price: "2.100 TL" },
        { label: "90×120 cm", price: "2.200 TL" },
      ],
    },
    {
      title: "1-6 Kişi Birleştirme Dahil",
      badge: "Geniş aile",
      sizes: [
        { label: "20×30 cm", price: "1.700 TL" },
        { label: "30×40 cm", price: "1.800 TL" },
        { label: "35×50 cm", price: "1.950 TL" },
        { label: "40×60 cm", price: "2.100 TL" },
        { label: "50×70 cm", price: "2.200 TL" },
        { label: "60×90 cm", price: "2.400 TL" },
        { label: "70×90 cm", price: "2.600 TL" },
        { label: "90×120 cm", price: "2.700 TL" },
      ],
    },
    {
      title: "9-10 Kişi Birleştirme Dahil",
      badge: "Kalabalık kompozisyon",
      sizes: [
        { label: "20×30 cm", price: "2.500 TL" },
        { label: "30×40 cm", price: "2.600 TL" },
        { label: "35×50 cm", price: "2.700 TL" },
        { label: "40×60 cm", price: "2.800 TL" },
        { label: "50×70 cm", price: "2.900 TL" },
        { label: "60×90 cm", price: "3.000 TL" },
        { label: "70×100 cm", price: "3.100 TL" },
        { label: "90×120 cm", price: "3.300 TL" },
      ],
    },
    {
      title: "1-3 Kişi Çerçeve Birleştirme Dahil",
      badge: "Çerçeve paketi",
      sizes: [
        { label: "15×21 cm", price: "1.950 TL" },
        { label: "21×30 cm", price: "2.300 TL" },
        { label: "30×40 cm", price: "2.500 TL" },
        { label: "50×70 cm", price: "3.000 TL" },
        { label: "70×110 cm", price: "4.100 TL" },
      ],
    },
  ];

  const reviews = [
    { name: "Ayşe K.", instagram: "@ayse.kaya", text: "Kalpten Kareler'den aldığım kanvas tablo harika oldu! Anneme hediye ettim, çok memnun kaldı. Kalitesi gerçekten mükemmel, renkleri canlı ve paketlemesi çok şık. Herkese tavsiye ediyorum! 💕", rating: 5 },
    { name: "Mehmet Y.", instagram: "@mehmet.yilmaz", text: "Kişiye özel tasarım tam istediğim gibi çıktı! Tasarımcı çok profesyonel, revizyon taleplerimi hemen karşıladı. Baskı kalitesi harika, çerçeve de çok güzel. Yeniden sipariş vereceğim!", rating: 5 },
    { name: "Zeynep D.", instagram: "@zeynep.design", text: "Hızlı kargo, güvenli paketleme ve müşteri hizmetleri çok iyi. Kanvas tablo beklediğimden daha güzel çıktı. Aile fotoğraflarım çok hoş görünüyor. Teşekkürler Kalpten Kareler! 🎨", rating: 5 },
    { name: "Leyla T.", instagram: "@leyla.tasarim", text: "Düğün fotoğraflarımızdan kanvas tablo yaptırdım. Tasarım süreci çok keyifliydi, her adımda bilgilendirildum. Sonuç mükemmel! Evimizin en güzel köşesinde asılı. Çok teşekkür ederim! 💍", rating: 5 },
    { name: "Fatih A.", instagram: "@fatih.art", text: "Babama hediye ettim, çok beğendi. Kalp şeklinde tasarım çok özel ve anlamlı oldu. Hızlı teslimat ve mükemmel ambalaj. Kalitesi konusunda hiç şüphe yok. Bravo! 👏", rating: 5 },
    { name: "Selin K.", instagram: "@selin.moments", text: "Çocuklarımın fotoğraflarından kanvas tablo yaptırdım. Renkleri çok canlı, detaylar çok net. Tasarımcı çok yaratıcı, benim fikrimi harika bir şekilde hayata geçirdi. Çok memnunum! 🌟", rating: 5 },
    { name: "Emre S.", instagram: "@emre.photo", text: "Profesyonel fotoğraflarımı kanvasa aktarttım. Baskı kalitesi fotoğraf kalitesini tamamen korumuş. Müşteri hizmetleri çok yardımcı ve güler yüzlü. Kesinlikle tavsiye ediyorum! ✨", rating: 5 },
    { name: "Nida B.", instagram: "@nida.home", text: "Evimizin dekorasyonu için kanvas tablo sipariş ettim. Tasarım süreci çok profesyonel, revizyon taleplerimi hemen karşıladılar. Sonuç beklediğimden çok daha güzel çıktı. Teşekkürler! 🏡", rating: 5 },
  ];

  const canvasExamples = [
    { title: "Aile Birleştirmesi", desc: "4-5 kişi profesyonel birleştirme", url: "https://d2xsxph8kpxj0f.cloudfront.net/310519663622892665/fgZemz5TuDdAEJjBVQMthx/canvas-family-merge-ZqwLM8xxpR3Jvy3CxhEgDG.webp" },
    { title: "Düğün Çifti", desc: "Gelin-damat premium tasarım", url: "https://d2xsxph8kpxj0f.cloudfront.net/310519663622892665/fgZemz5TuDdAEJjBVQMthx/canvas-wedding-couple-NPWuNMhRp9yMkJUVsbMAqu.webp" },
  ];

  const handleWhatsAppOrder = (product?: string) => {
    const message = activeCampaign 
      ? `Merhaba! ${campaigns.find(c => c.id === activeCampaign)?.title} kampanyasından sipariş vermek istiyorum.`
      : `Merhaba! ${product || 'Kanvas Tablo'} için sipariş vermek istiyorum.`;
    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
  };

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    
    try {
      await createLeadMutation.mutateAsync({
        name: "Newsletter Subscriber",
        email: newsletterEmail,
        whatsappNumber: "0",
        source: "newsletter",
      });
      toast.success("Email başarıyla kaydedildi!");
      setNewsletterEmail("");
    } catch (error) {
      toast.error("Hata oluştu. Lütfen tekrar deneyin.");
    }
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.surname || !contactForm.phone) {
      toast.error("Lütfen tüm alanları doldurun");
      return;
    }

    try {
      await createLeadMutation.mutateAsync({
        name: `${contactForm.name} ${contactForm.surname}`,
        whatsappNumber: contactForm.phone,
        source: "contact_form",
      });
      toast.success("Bilgileriniz başarıyla kaydedildi!");
      setContactForm({ name: "", surname: "", phone: "" });
    } catch (error) {
      toast.error("Hata oluştu. Lütfen tekrar deneyin.");
    }
  };

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % canvasExamples.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + canvasExamples.length) % canvasExamples.length);
  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} kopyalandı!`);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <img src="/manus-storage/kalpten-kareler-icon-instagram_379e4e28.png" alt="Kalpten Kareler Logo" className="w-12 h-12" />
            <h1 className="text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>Kalpten Kareler</h1>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => setShowWhatsAppPopup(true)} className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg">
              <MessageCircle className="w-5 h-5" />
              <span className="hidden sm:inline text-sm font-medium">WhatsApp</span>
            </button>
            <a href="https://www.instagram.com/kalptenkarelerr/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-rose-500 hover:text-rose-600">
              <Instagram className="w-5 h-5" />
            </a>
          </div>
        </div>
      </nav>

      {/* CTA Section - En Üste */}
      <section className="bg-gradient-to-r from-rose-100 via-teal-100 to-amber-100 py-12 lg:py-16">
        <div className="container text-center space-y-6">
          <h2 className="text-4xl md:text-5xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
            Sevdiklerinize Ömürlük Hediye Vermeye Hazır mısınız?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Kalpten Kareler ile her anı kalıcı hale getirin. WhatsApp veya Instagram'dan bize ulaşın.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button onClick={() => setShowWhatsAppPopup(true)} className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded-lg font-semibold flex items-center justify-center gap-2">
              <MessageCircle className="w-5 h-5" />
              WhatsApp Sipariş Ver
            </button>
            <Button size="lg" className="bg-rose-500 hover:bg-rose-600 text-white">
              Instagram'dan Bize Ulaşın
            </Button>
          </div>
        </div>
      </section>


      {/* Canvas Examples - En Üste */}
      <section className="bg-gradient-to-br from-rose-50 via-teal-50 to-amber-50 py-16 lg:py-24">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
              Kanvas Tablo Örnekleri
            </h2>
          </div>
          <div className="relative bg-card rounded-lg overflow-hidden shadow-lg">
            <div className="aspect-video relative">
              <img src={canvasExamples[currentSlide].url} alt={canvasExamples[currentSlide].title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                <div className="p-6 text-white w-full">
                  <h3 className="text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
                    {canvasExamples[currentSlide].title}
                  </h3>
                  <p className="text-white/80">{canvasExamples[currentSlide].desc}</p>
                </div>
              </div>
            </div>
            <button onClick={prevSlide} className="absolute left-4 top-1/2 -translate-y-1/2 bg-rose-500/80 hover:bg-rose-500 text-white p-2 rounded-full">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button onClick={nextSlide} className="absolute right-4 top-1/2 -translate-y-1/2 bg-rose-500/80 hover:bg-rose-500 text-white p-2 rounded-full">
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-16 lg:py-24 bg-background">
        <div className="container space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
              Kanvas Tablo Fiyatları
            </h2>
            <Button onClick={() => setShowPricing(!showPricing)} className="mx-auto bg-rose-500 hover:bg-rose-600">
              {showPricing ? "Fiyatları Gizle" : "Tüm Fiyatları Gör"}
            </Button>
          </div>

          {showPricing && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {canvasPricing.map((tier, idx) => (
                <Card key={idx} className="p-6 space-y-4 border-rose-200 bg-gradient-to-br from-rose-50 to-amber-50 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-bold text-lg text-rose-700">{tier.title}</h3>
                    <span className="shrink-0 text-[11px] uppercase tracking-[0.18em] text-amber-700 bg-amber-100 border border-amber-200 rounded-full px-3 py-1">{tier.badge}</span>
                  </div>
                  <div className="space-y-2">
                    {tier.sizes.map((size, sizeIdx) => (
                      <div key={sizeIdx} className="flex justify-between gap-4 items-start text-sm py-1.5 border-b border-rose-200/50">
                        <span className="text-foreground">
                          {size.label}
                          {size.note && <span className="block text-xs text-amber-700 mt-0.5">{size.note}</span>}
                        </span>
                        <span className="font-semibold text-rose-700 whitespace-nowrap">{size.price}</span>
                      </div>
                    ))}
                  </div>
                  <button onClick={() => handleWhatsAppOrder(`Kanvas - ${tier.title}`)} className="w-full mt-4 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-semibold text-sm transition-colors">
                    WhatsApp Sipariş Ver
                  </button>
                </Card>
              ))}
            </div>
          )}

          <div className="bg-gradient-to-r from-teal-100 to-blue-100 border-2 border-teal-300 rounded-lg p-6 text-center">
            <p className="text-lg font-semibold text-foreground">📩 Dijital Gönderim Seçeneği Mevcuttur</p>
            <p className="text-muted-foreground mt-2">Tasarımınızı dijital olarak da alabilirsiniz</p>
          </div>
        </div>
      </section>

      {/* Seasonal Campaigns */}
      <section className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 py-16 lg:py-24">
        <div className="container">
          <div className="text-center mb-12 space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold text-white" style={{ fontFamily: "'Playfair Display', serif" }}>
              Özel Kampanyalar
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {campaigns.map((campaign) => (
              <motion.div
                key={campaign.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                whileHover={{ y: -8 }}
                className="relative group cursor-pointer rounded-lg overflow-hidden shadow-xl"
              >
                <div className="relative h-80 overflow-hidden">
                  <img src={campaign.image} alt={campaign.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition-colors" />
                </div>
                <motion.div className={`absolute top-4 right-4 bg-gradient-to-br ${campaign.color} text-white px-4 py-2 rounded-full font-bold text-lg`}>
                  {campaign.discount} İndirim
                </motion.div>
                <div className={`${campaign.bgColor} p-6 space-y-3`}>
                  <h3 className="text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>{campaign.title}</h3>
                  <p className="text-muted-foreground">{campaign.subtitle}</p>
                  {timeLeft[campaign.id] && (
                    <div className="bg-red-100 border border-red-300 rounded-lg p-3 text-center">
                      <p className="text-xs font-semibold text-red-700">⏰ Kalan Süre</p>
                      <p className="text-sm font-bold text-red-600">{timeLeft[campaign.id]}</p>
                    </div>
                  )}
                  <button onClick={() => handleWhatsAppOrder(campaign.title)} className={`w-full bg-gradient-to-r ${campaign.color} text-white py-2 rounded-lg font-semibold`}>
                    Hemen Sipariş Ver
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Customer Reviews - Dynamic Carousel */}
      <ReviewsCarousel />

      {/* Contact Form - En Altta */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="container max-w-md mx-auto space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
              Bize Ulaşın
            </h2>
            <p className="text-muted-foreground">Müşteri bilgilerinizi bırakın, en kısa sürede sizinle iletişime geçeceğiz</p>
          </div>
          <form onSubmit={handleContactSubmit} className="space-y-4">
            <input
              type="text"
              placeholder="Adınız"
              value={contactForm.name}
              onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
              className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
              required
            />
            <input
              type="text"
              placeholder="Soyadınız"
              value={contactForm.surname}
              onChange={(e) => setContactForm({ ...contactForm, surname: e.target.value })}
              className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
              required
            />
            <input
              type="tel"
              placeholder="Telefon Numarası"
              value={contactForm.phone}
              onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
              className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
              required
            />
            <Button type="submit" className="w-full bg-rose-500 hover:bg-rose-600 text-white">
              Gönder
            </Button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-rose-200 bg-gradient-to-br from-rose-50 to-amber-50 py-6">
        <div className="container space-y-4">
          <div className="flex items-center justify-center gap-3 pb-4 border-b border-rose-200">
            <img src="/manus-storage/kalpten-kareler-icon-instagram_379e4e28.png" alt="Kalpten Kareler Logo" className="w-10 h-10" />
            <span className="font-bold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>Kalpten Kareler</span>
          </div>
          <div className="text-center text-sm text-muted-foreground space-y-2">
            <p>© 2026 Kalpten Kareler. Tüm hakları saklıdır.</p>
            <p>
              <a href="https://www.instagram.com/kalptenkarelerr/" target="_blank" rel="noopener noreferrer" className="text-rose-600 hover:underline">
                Instagram
              </a>
              {" • "}
              <a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noopener noreferrer" className="text-green-600 hover:underline">
                WhatsApp
              </a>
            </p>
          </div>
        </div>
      </footer>

      {/* Modals */}
      {showReviewForm && (
        <div className="fixed inset-0 bg-black/50 z-40 flex items-center justify-center p-4">
          <div className="bg-card rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-4 sticky top-0 bg-card pb-2">
              <h3 className="text-2xl font-bold">Yorum Yaz</h3>
              <button onClick={() => setShowReviewForm(false)} className="text-muted-foreground hover:text-foreground flex-shrink-0 ml-4">
                <X className="w-6 h-6" />
              </button>
            </div>
            <ReviewForm onSuccess={() => setShowReviewForm(false)} />
          </div>
        </div>
      )}

      {showWhatsAppPopup && (
        <div className="fixed inset-0 bg-black/50 z-40 flex items-center justify-center p-4">
          <Card className="w-full max-w-md bg-card p-6 space-y-4">
            <h3 className="text-2xl font-bold">WhatsApp'tan Sipariş Ver</h3>
            <button onClick={() => { handleWhatsAppOrder("Kanvas Tablo"); setShowWhatsAppPopup(false); }} className="w-full p-3 text-left bg-secondary/50 hover:bg-secondary rounded-lg">
              Kanvas Tablo
            </button>
            <button onClick={() => { handleWhatsAppOrder("Çerçeveli Fotoğraf"); setShowWhatsAppPopup(false); }} className="w-full p-3 text-left bg-secondary/50 hover:bg-secondary rounded-lg">
              Çerçeveli Fotoğraf
            </button>
            <button onClick={() => setShowWhatsAppPopup(false)} className="w-full p-2 border border-border rounded-lg hover:bg-secondary/30">
              Kapat
            </button>
          </Card>
        </div>
      )}
    </div>
  );
}
