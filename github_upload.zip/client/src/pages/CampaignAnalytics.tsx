import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, TrendingUp, Users, ShoppingCart, Target } from "lucide-react";

export default function CampaignAnalytics() {
  const { user, isAuthenticated } = useAuth();
  const [selectedCampaign, setSelectedCampaign] = useState("mothers-day");

  // Queries
  const analyticsQuery = trpc.analytics.getByCampaign.useQuery(
    { campaign: selectedCampaign },
    { enabled: isAuthenticated && user?.role === "admin" }
  );

  // Role check
  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="p-8 max-w-md text-center space-y-4">
          <AlertCircle className="w-12 h-12 mx-auto text-destructive" />
          <h1 className="text-2xl font-bold">Yetkisiz Erişim</h1>
          <p className="text-muted-foreground">
            Bu sayfaya erişmek için admin yetkisine sahip olmanız gerekir.
          </p>
        </Card>
      </div>
    );
  }

  const campaigns = [
    { id: "mothers-day", label: "Anneler Günü" },
    { id: "fathers-day", label: "Babalar Günü" },
    { id: "newyear", label: "Yılbaşı" },
  ];

  const analytics = analyticsQuery.data && Array.isArray(analyticsQuery.data) 
    ? analyticsQuery.data[0] 
    : analyticsQuery.data;

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 space-y-8">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-4xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
            Kampanya Analitikleri
          </h1>
          <p className="text-muted-foreground">
            Kampanya performans metrikleri ve dönüşüm oranları
          </p>
        </div>

        {/* Campaign Selector */}
        <div className="flex gap-2 flex-wrap">
          {campaigns.map((campaign) => (
            <Button
              key={campaign.id}
              onClick={() => setSelectedCampaign(campaign.id)}
              variant={selectedCampaign === campaign.id ? "default" : "outline"}
              className={
                selectedCampaign === campaign.id
                  ? "bg-accent hover:bg-accent/80"
                  : ""
              }
            >
              {campaign.label}
            </Button>
          ))}
        </div>

        {/* Stats Grid */}
        {analyticsQuery.isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="h-4 bg-secondary rounded mb-4 w-1/2" />
                <div className="h-8 bg-secondary rounded" />
              </Card>
            ))}
          </div>
        ) : analytics ? (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="p-6 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm">Sayfa Görüntüleme</span>
                <TrendingUp className="w-5 h-5 text-accent" />
              </div>
              <p className="text-3xl font-bold">
                {analytics?.pageViews || 0}
              </p>
            </Card>

            <Card className="p-6 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm">Benzersiz Ziyaretçi</span>
                <Users className="w-5 h-5 text-blue-500" />
              </div>
              <p className="text-3xl font-bold">
                {analytics?.uniqueVisitors || 0}
              </p>
            </Card>

            <Card className="p-6 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm">Oluşturulan Leads</span>
                <Target className="w-5 h-5 text-amber-500" />
              </div>
              <p className="text-3xl font-bold">
                {analytics?.leadsGenerated || 0}
              </p>
            </Card>

            <Card className="p-6 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground text-sm">Oluşturulan Siparişler</span>
                <ShoppingCart className="w-5 h-5 text-green-500" />
              </div>
              <p className="text-3xl font-bold">
                {analytics?.ordersCreated || 0}
              </p>
            </Card>
          </div>
        ) : (
          <Card className="p-8 text-center text-muted-foreground">
            Kampanya verisi bulunamadı
          </Card>
        )}

        {/* Conversion Metrics */}
        {analytics && (
          <Card className="p-8 space-y-8">
            <h2 className="text-2xl font-bold">Dönüşüm Metrikleri</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Conversion Rate */}
              <div className="space-y-4">
                <p className="text-muted-foreground">Dönüşüm Oranı</p>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-accent">
                    {analytics.leadsGenerated && analytics.leadsGenerated > 0
                      ? Math.round(
                          ((analytics.ordersCreated || 0) /
                            analytics.leadsGenerated) *
                            100
                        )
                      : 0}
                    %
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {analytics.ordersCreated || 0} sipariş /{" "}
                    {analytics.leadsGenerated || 0} lead
                  </p>
                </div>
              </div>

              {/* Lead to Visitor Ratio */}
              <div className="space-y-4">
                <p className="text-muted-foreground">Lead/Ziyaretçi Oranı</p>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-blue-500">
                    {analytics.uniqueVisitors && analytics.uniqueVisitors > 0
                      ? (
                          ((analytics.leadsGenerated || 0) /
                            analytics.uniqueVisitors) *
                          100
                        ).toFixed(1)
                      : 0}
                    %
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {analytics.leadsGenerated || 0} lead /{" "}
                    {analytics.uniqueVisitors || 0} ziyaretçi
                  </p>
                </div>
              </div>

              {/* Engagement Rate */}
              <div className="space-y-4">
                <p className="text-muted-foreground">Katılım Oranı</p>
                <div className="space-y-2">
                  <div className="text-4xl font-bold text-amber-500">
                    {analytics.pageViews && analytics.pageViews > 0
                      ? (
                          ((analytics.leadsGenerated || 0) /
                            analytics.pageViews) *
                          100
                        ).toFixed(2)
                      : 0}
                    %
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {analytics.leadsGenerated || 0} lead /{" "}
                    {analytics.pageViews || 0} görüntüleme
                  </p>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Insights */}
        <Card className="p-8 space-y-4 bg-accent/5 border-l-4 border-accent">
          <h2 className="text-xl font-bold">İçgörüler</h2>
          <ul className="space-y-2 text-muted-foreground">
            <li className="flex gap-2">
              <span>•</span>
              <span>
                {analytics?.pageViews && analytics.pageViews > 100
                  ? "Kampanyanız yüksek trafik alıyor. Dönüşüm oranını artırmak için landing page'i optimize edin."
                  : "Kampanyanız henüz yeterli trafik almıyor. Pazarlama çabalarını artırın."}
              </span>
            </li>
            <li className="flex gap-2">
              <span>•</span>
              <span>
                {analytics?.leadsGenerated && analytics.leadsGenerated > 0
                  ? `Toplam ${analytics.leadsGenerated} lead oluşturulmuş. Bunlardan ${analytics.ordersCreated || 0} tanesi sipariş haline geldi.`
                  : "Henüz lead oluşturulmamış. Kampanya başlat veya pazarlama çabalarını artır."}
              </span>
            </li>
            <li className="flex gap-2">
              <span>•</span>
              <span>
                Kampanya başarısını ölçmek için düzenli olarak bu metrikleri kontrol edin.
              </span>
            </li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
