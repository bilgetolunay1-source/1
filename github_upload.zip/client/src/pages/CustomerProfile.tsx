import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, ShoppingCart, User, LogOut } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function CustomerProfile() {
  const { user, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();

  // Queries - user'ın ID'sini kullanarak müşteri bilgisini al
  // Not: Gerçek uygulamada user.id = customerId olması gerekir
  const customerQuery = trpc.customers.getById.useQuery(
    { customerId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  const ordersQuery = trpc.orders.getByCustomer.useQuery(
    { customerId: customerQuery.data?.id || 0 },
    { enabled: !!customerQuery.data?.id }
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="p-8 max-w-md text-center space-y-4">
          <AlertCircle className="w-12 h-12 mx-auto text-destructive" />
          <h1 className="text-2xl font-bold">Giriş Yapmanız Gerekir</h1>
          <p className="text-muted-foreground">
            Profilinizi görmek için lütfen giriş yapın.
          </p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="w-full bg-accent hover:bg-accent/80"
          >
            Giriş Yap
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="space-y-2">
            <h1 className="text-4xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
              Profilim
            </h1>
            <p className="text-muted-foreground">
              Kişisel bilgileriniz ve siparişleriniz
            </p>
          </div>
          <Button
            onClick={logout}
            variant="outline"
            className="flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            Çıkış Yap
          </Button>
        </div>

        {/* Profile Info */}
        <Card className="p-8 space-y-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center">
              <User className="w-8 h-8 text-accent" />
            </div>
            <div className="space-y-1">
              <h2 className="text-2xl font-bold">{user?.name}</h2>
              <p className="text-muted-foreground">{user?.email}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-border">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Kayıt Tarihi</p>
              <p className="font-semibold">
                {user?.createdAt
                  ? new Date(user.createdAt).toLocaleDateString("tr-TR")
                  : "-"}
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Son Giriş</p>
              <p className="font-semibold">
                {user?.lastSignedIn
                  ? new Date(user.lastSignedIn).toLocaleDateString("tr-TR")
                  : "-"}
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Toplam Siparişler</p>
              <p className="font-semibold">{ordersQuery.data?.length || 0}</p>
            </div>
          </div>
        </Card>

        {/* Orders Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-6 h-6 text-accent" />
            <h2 className="text-2xl font-bold">Siparişlerim</h2>
          </div>

          {ordersQuery.isLoading && (
            <Card className="p-8 text-center text-muted-foreground">
              Yükleniyor...
            </Card>
          )}

          {ordersQuery.data && ordersQuery.data.length === 0 && (
            <Card className="p-8 text-center space-y-4">
              <ShoppingCart className="w-12 h-12 mx-auto text-muted-foreground" />
              <p className="text-muted-foreground">
                Henüz siparişiniz yok. Şimdi sipariş vermek için ana sayfaya dönün.
              </p>
              <Button
                onClick={() => (window.location.href = "/")}
                className="bg-accent hover:bg-accent/80"
              >
                Ana Sayfaya Dön
              </Button>
            </Card>
          )}

          {ordersQuery.data && ordersQuery.data.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {ordersQuery.data.map((order) => (
                <Card key={order.id} className="p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold">Sipariş #{order.id}</h3>
                    <span className="px-3 py-1 bg-accent/10 text-accent rounded-full text-xs font-semibold">
                      {order.status === "pending" && "Beklemede"}
                      {order.status === "designing" && "Tasarlanıyor"}
                      {order.status === "approved" && "Onaylandı"}
                      {order.status === "printing" && "Baskıda"}
                      {order.status === "shipped" && "Gönderildi"}
                      {order.status === "delivered" && "Teslim Edildi"}
                      {order.status === "cancelled" && "İptal"}
                    </span>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Ürün Türü:</span>
                      <span className="font-semibold">
                        {order.productType === "canvas" && "Kanvas Tablo"}
                        {order.productType === "frame" && "Çerçeveli Fotoğraf"}
                        {order.productType === "digital" && "Dijital Tasarım"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Boyut:</span>
                      <span className="font-semibold">{order.size || "-"}</span>
                    </div>
                    {order.personCount && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Kişi Sayısı:</span>
                        <span className="font-semibold">{order.personCount}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Fiyat:</span>
                      <span className="font-semibold">
                        {typeof order.price === "string"
                          ? parseFloat(order.price).toLocaleString("tr-TR")
                          : Number(order.price || 0).toLocaleString("tr-TR")}{" "}
                        ₺
                      </span>
                    </div>
                    {order.campaign && (
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Kampanya:</span>
                        <span className="font-semibold">{order.campaign}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Tarih:</span>
                      <span className="font-semibold">
                        {new Date(order.createdAt).toLocaleDateString("tr-TR")}
                      </span>
                    </div>
                  </div>

                  {order.designNotes && (
                    <div className="pt-4 border-t border-border">
                      <p className="text-xs text-muted-foreground mb-2">Tasarım Notları:</p>
                      <p className="text-sm">{order.designNotes}</p>
                    </div>
                  )}

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => setLocation(`/order/${order.id}`)}
                  >
                    Detayları Gör
                  </Button>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
