import { MessageCircle } from 'lucide-react';
import { useState } from 'react';
import { motion } from 'framer-motion';

const WHATSAPP_NUMBER = "905469580230";

export function FloatingWhatsAppButton() {
  const [isOpen, setIsOpen] = useState(false);

  const handleWhatsAppClick = () => {
    const message = "Merhaba! Kalpten Kareler hakkında bilgi almak istiyorum.";
    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
  };

  return (
    <>
      {/* Floating Button */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-8 right-8 z-50 bg-green-500 hover:bg-green-600 text-white rounded-full p-4 shadow-lg hover:shadow-xl transition-all"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        animate={{ y: [0, -10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <MessageCircle className="w-6 h-6" />
      </motion.button>

      {/* Popup Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 20 }}
          className="fixed bottom-24 right-8 z-50 bg-white rounded-lg shadow-xl p-4 max-w-xs"
        >
          <div className="space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-gray-200">
              <MessageCircle className="w-5 h-5 text-green-500" />
              <h3 className="font-bold text-foreground">Bize Ulaşın</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              WhatsApp üzerinden bize yazın, en kısa sürede yanıt vereceğiz.
            </p>
            <button
              onClick={handleWhatsAppClick}
              className="w-full bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors text-sm"
            >
              WhatsApp'ta Aç
            </button>
            <button
              onClick={() => setIsOpen(false)}
              className="w-full border border-gray-300 text-foreground px-4 py-2 rounded-lg font-semibold transition-colors text-sm hover:bg-gray-50"
            >
              Kapat
            </button>
          </div>
        </motion.div>
      )}
    </>
  );
}
