import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface Review {
  id: number;
  name: string;
  rating: number;
  title?: string;
  comment: string;
  createdAt: Date;
}

export default function ReviewsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);

  // Fetch approved reviews from API
  const { data: reviews = [], isLoading } = trpc.reviews.getApproved.useQuery(
    { limit: 10 },
    { refetchInterval: 30000 } // Refresh every 30 seconds
  );

  // Auto-advance carousel
  useEffect(() => {
    if (!autoPlay || reviews.length === 0) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % reviews.length);
    }, 5000); // Change every 5 seconds

    return () => clearInterval(interval);
  }, [autoPlay, reviews.length]);

  const goToPrevious = () => {
    setAutoPlay(false);
    setCurrentIndex((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  const goToNext = () => {
    setAutoPlay(false);
    setCurrentIndex((prev) => (prev + 1) % reviews.length);
  };

  if (isLoading || reviews.length === 0) {
    return null; // Don't show section if no reviews
  }

  const currentReview = reviews[currentIndex];

  return (
    <section className="py-16 bg-gradient-to-br from-rose-50 via-amber-50 to-yellow-50">
      <div className="container max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h2
            className="text-4xl md:text-5xl font-bold text-foreground mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            Müşteri Yorumları
          </h2>
          <p className="text-muted-foreground text-lg">
            Kalpten Kareler'i tercih eden müşterilerimizin deneyimleri
          </p>
        </div>

        {/* Carousel Container */}
        <div className="relative">
          {/* Review Card */}
          <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12 min-h-[400px] flex flex-col justify-between">
            {/* Stars */}
            <div className="flex gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-5 h-5 ${
                    i < currentReview.rating
                      ? "fill-amber-400 text-amber-400"
                      : "text-gray-300"
                  }`}
                />
              ))}
            </div>

            {/* Title */}
            {currentReview.title && (
              <h3 className="text-2xl font-bold text-foreground mb-4">
                {currentReview.title}
              </h3>
            )}

            {/* Comment */}
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed italic">
              "{currentReview.comment}"
            </p>

            {/* Author */}
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-rose-400 to-amber-400 flex items-center justify-center text-white font-bold text-lg">
                {currentReview.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="font-semibold text-foreground">
                  {currentReview.name}
                </p>
                <p className="text-sm text-muted-foreground">
                  {new Date(currentReview.createdAt).toLocaleDateString("tr-TR", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between mt-8">
            <button
              onClick={goToPrevious}
              className="p-3 rounded-full bg-white shadow-md hover:shadow-lg hover:bg-gray-50 transition-all"
              aria-label="Önceki yorum"
            >
              <ChevronLeft className="w-6 h-6 text-foreground" />
            </button>

            {/* Dots */}
            <div className="flex gap-2">
              {reviews.map((_, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setAutoPlay(false);
                    setCurrentIndex(index);
                  }}
                  className={`h-2 rounded-full transition-all ${
                    index === currentIndex
                      ? "bg-rose-500 w-8"
                      : "bg-gray-300 w-2 hover:bg-gray-400"
                  }`}
                  aria-label={`Yorum ${index + 1}`}
                />
              ))}
            </div>

            <button
              onClick={goToNext}
              className="p-3 rounded-full bg-white shadow-md hover:shadow-lg hover:bg-gray-50 transition-all"
              aria-label="Sonraki yorum"
            >
              <ChevronRight className="w-6 h-6 text-foreground" />
            </button>
          </div>

          {/* Resume Auto-play hint */}
          <p className="text-center text-sm text-muted-foreground mt-6">
            Otomatik oynatma {autoPlay ? "aktif" : "durduruldu"}
          </p>
        </div>

        {/* CTA Button */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">
            Sizin de deneyiminizi paylaşmak ister misiniz?
          </p>
          <button className="bg-rose-500 hover:bg-rose-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors">
            Yorum Yaz
          </button>
        </div>
      </div>
    </section>
  );
}
