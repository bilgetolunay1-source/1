import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { MessageCircle } from "lucide-react";

interface LeadFormProps {
  campaign?: string;
  source?: string;
  onSuccess?: () => void;
}

export function LeadForm({ campaign, source = "website", onSuccess }: LeadFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    whatsappNumber: "",
    interestedProduct: "canvas",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const createLeadMutation = trpc.leads.create.useMutation({
    onSuccess: () => {
      toast.success("Bilgileriniz kaydedildi! Kısa sürede sizinle iletişime geçeceğiz.");
      setFormData({
        name: "",
        email: "",
        whatsappNumber: "",
        interestedProduct: "canvas",
        message: "",
      });
      onSuccess?.();
    },
    onError: (error) => {
      toast.error("Bir hata oluştu. Lütfen tekrar deneyin.");
      console.error("Lead creation error:", error);
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.whatsappNumber) {
      toast.error("Lütfen adınız ve WhatsApp numaranızı girin.");
      return;
    }

    setIsSubmitting(true);

    try {
      await createLeadMutation.mutateAsync({
        name: formData.name,
        email: formData.email || undefined,
        whatsappNumber: formData.whatsappNumber,
        source: source,
        interestedProduct: formData.interestedProduct,
        message: formData.message,
        campaign: campaign,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-md bg-card p-6 space-y-4">
      <div className="space-y-2">
        <h3 className="text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
          Bize Ulaşın
        </h3>
        <p className="text-sm text-muted-foreground">
          Bilgilerinizi paylaşın, size özel bir teklif hazırlayalım.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Name */}
        <div>
          <label className="text-sm font-medium text-foreground">
            Adınız *
          </label>
          <input
            type="text"
            placeholder="Adınız"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            disabled={isSubmitting}
          />
        </div>

        {/* Email */}
        <div>
          <label className="text-sm font-medium text-foreground">
            E-posta (opsiyonel)
          </label>
          <input
            type="email"
            placeholder="E-posta adresiniz"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            disabled={isSubmitting}
          />
        </div>

        {/* WhatsApp Number */}
        <div>
          <label className="text-sm font-medium text-foreground">
            WhatsApp Numarası * (örn: 5051234567)
          </label>
          <input
            type="tel"
            placeholder="5051234567"
            value={formData.whatsappNumber}
            onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            disabled={isSubmitting}
          />
        </div>

        {/* Product Interest */}
        <div>
          <label className="text-sm font-medium text-foreground">
            İlgilendiğiniz Ürün
          </label>
          <select
            value={formData.interestedProduct}
            onChange={(e) => setFormData({ ...formData, interestedProduct: e.target.value })}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            disabled={isSubmitting}
          >
            <option value="canvas">Kanvas Tablo</option>
            <option value="frame">Çerçeveli Fotoğraf</option>
            <option value="digital">Dijital Tasarım</option>
            <option value="other">Diğer</option>
          </select>
        </div>

        {/* Message */}
        <div>
          <label className="text-sm font-medium text-foreground">
            Mesajınız (opsiyonel)
          </label>
          <textarea
            placeholder="Özel istekleriniz veya sorularınız..."
            value={formData.message}
            onChange={(e) => setFormData({ ...formData, message: e.target.value })}
            rows={3}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent resize-none"
            disabled={isSubmitting}
          />
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={isSubmitting || createLeadMutation.isPending}
          className="w-full bg-green-500 hover:bg-green-600 text-white font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
        >
          <MessageCircle className="w-4 h-4" />
          {isSubmitting || createLeadMutation.isPending ? "Gönderiliyor..." : "Bilgi Gönder"}
        </Button>
      </form>

      <p className="text-xs text-muted-foreground text-center">
        Bilgileriniz güvenli bir şekilde kaydedilecek ve sadece sizinle iletişim için kullanılacaktır.
      </p>
    </Card>
  );
}
