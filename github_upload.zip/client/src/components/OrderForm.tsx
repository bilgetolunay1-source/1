import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ShoppingCart } from "lucide-react";

interface OrderFormProps {
  customerId: number;
  campaign?: string;
  onSuccess?: (orderId: number) => void;
}

export function OrderForm({ customerId, campaign, onSuccess }: OrderFormProps) {
  const [formData, setFormData] = useState({
    productType: "canvas" as "canvas" | "frame" | "digital",
    size: "50x70 cm",
    personCount: 3,
    price: 1800,
    designNotes: "",
    customizationText: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const createOrderMutation = trpc.orders.create.useMutation({
    onSuccess: (result) => {
      toast.success("Siparişiniz başarıyla oluşturuldu!");
      onSuccess?.(result.orderId);
    },
    onError: (error) => {
      toast.error("Sipariş oluşturulurken bir hata oluştu.");
      console.error("Order creation error:", error);
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setIsSubmitting(true);

    try {
      await createOrderMutation.mutateAsync({
        customerId,
        productType: formData.productType,
        size: formData.size,
        personCount: formData.productType === "digital" ? undefined : formData.personCount,
        price: formData.price,
        campaign: campaign,
        designNotes: formData.designNotes,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const canvasPrices: Record<number, Record<string, number>> = {
    3: {
      "20x30 cm": 1400,
      "30x40 cm": 1500,
      "35x50 cm": 1600,
      "40x60 cm": 1700,
      "50x70 cm": 1800,
      "60x90 cm": 1900,
      "70x90 cm": 2000,
      "90x120 cm": 2100,
    },
    5: {
      "20x30 cm": 1500,
      "30x40 cm": 1600,
      "35x50 cm": 1700,
      "40x60 cm": 1800,
      "50x70 cm": 1900,
      "60x90 cm": 2000,
      "70x100 cm": 2100,
      "90x120 cm": 2200,
    },
    6: {
      "20x30 cm": 1700,
      "30x40 cm": 1800,
      "35x50 cm": 1950,
      "40x60 cm": 2100,
      "50x70 cm": 2200,
      "60x90 cm": 2400,
      "70x90 cm": 2600,
      "90x120 cm": 2700,
    },
    10: {
      "20x30 cm": 2500,
      "30x40 cm": 2600,
      "35x50 cm": 2700,
      "40x60 cm": 2800,
      "50x70 cm": 2900,
      "60x90 cm": 3000,
      "70x100 cm": 3100,
      "90x120 cm": 3300,
    },
  };

  const framePrices: Record<string, number> = {
    "15x21 cm": 1950,
    "21x30 cm": 2300,
    "30x40 cm": 2500,
    "50x70 cm": 3000,
    "70x110 cm": 4100,
  };

  const getPrice = (productType: "canvas" | "frame" | "digital", size: string, personCount: number) => {
    if (productType === "digital") return 500;
    if (productType === "frame") return framePrices[size] || 1200;
    return canvasPrices[personCount]?.[size] || canvasPrices[3][size] || 1400;
  };

  const handleFormChange = (updates: Partial<typeof formData>) => {
    setFormData((prev) => {
      const next = { ...prev, ...updates };
      return {
        ...next,
        price: getPrice(next.productType, next.size, next.personCount),
      };
    });
  };

  const handleSizeChange = (size: string) => {
    handleFormChange({ size });
  };

  return (
    <Card className="w-full max-w-md bg-card p-6 space-y-4">
      <div className="space-y-2">
        <h3 className="text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
          Sipariş Oluştur
        </h3>
        <p className="text-sm text-muted-foreground">
          Ürün türü ve boyutunu seçin.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Product Type */}
        <div>
          <label className="text-sm font-medium text-foreground">
            Ürün Türü
          </label>
          <select
            value={formData.productType}
              onChange={(e) => {
              const type = e.target.value as "canvas" | "frame" | "digital";
              handleFormChange({ productType: type });
            }}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            disabled={isSubmitting}
          >
            <option value="canvas">Kanvas Tablo</option>
            <option value="frame">Çerçeveli Fotoğraf</option>
            <option value="digital">Dijital Tasarım</option>
          </select>
        </div>

        {/* Person Count */}
        {formData.productType !== "digital" && (
          <div>
            <label className="text-sm font-medium text-foreground">
              Kaç Kişi?
            </label>
            <select
              value={formData.personCount}
              onChange={(e) => {
                const count = parseInt(e.target.value);
                handleFormChange({ personCount: count });
              }}
              className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
              disabled={isSubmitting}
            >
              <option value="3">1-3 Kişi</option>
              <option value="5">1-5 Kişi</option>
              <option value="6">1-6 Kişi</option>
              <option value="10">9-10 Kişi</option>
            </select>
          </div>
        )}

        {/* Size */}
        <div>
          <label className="text-sm font-medium text-foreground">
            Boyut
          </label>
          <select
            value={formData.size}
            onChange={(e) => handleSizeChange(e.target.value)}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            disabled={isSubmitting}
          >
            <option value="20x30 cm">20×30 cm</option>
            <option value="30x40 cm">30×40 cm</option>
            <option value="35x50 cm">35×50 cm</option>
            <option value="40x60 cm">40×60 cm</option>
            <option value="50x70 cm">50×70 cm</option>
            <option value="60x90 cm">60×90 cm</option>
            <option value="70x90 cm">70×90 cm</option>
            <option value="70x100 cm">70×100 cm</option>
            <option value="90x120 cm">90×120 cm</option>
          </select>
        </div>

        {/* Price */}
        <div>
          <label className="text-sm font-medium text-foreground">
            Fiyat
          </label>
          <div className="px-3 py-2 border border-border rounded-lg bg-secondary/50 text-foreground font-semibold">
            {formData.price.toLocaleString("tr-TR")} ₺
          </div>
        </div>

        {/* Design Notes */}
        <div>
          <label className="text-sm font-medium text-foreground">
            Tasarım Notları (opsiyonel)
          </label>
          <textarea
            placeholder="Özel istekleriniz..."
            value={formData.designNotes}
            onChange={(e) => setFormData({ ...formData, designNotes: e.target.value })}
            rows={3}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent resize-none"
            disabled={isSubmitting}
          />
        </div>

        {/* Customization Text */}
        <div>
          <label className="text-sm font-medium text-foreground">
            Kişiselleştirme Metni (opsiyonel)
          </label>
          <textarea
            placeholder="Örn: Sevgili Anneme, 10 Mayıs 2026"
            value={formData.customizationText}
            onChange={(e) => setFormData({ ...formData, customizationText: e.target.value })}
            rows={2}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent resize-none"
            disabled={isSubmitting}
          />
          <p className="text-xs text-muted-foreground mt-1">
            Ürüne eklenecek özel metni yazın (tarih, isim, kısa mesaj vb.)
          </p>
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={isSubmitting || createOrderMutation.isPending}
          className="w-full bg-rose-500 hover:bg-rose-600 text-white font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-2"
        >
          <ShoppingCart className="w-4 h-4" />
          {isSubmitting || createOrderMutation.isPending ? "Oluşturuluyor..." : "Sipariş Oluştur"}
        </Button>
      </form>

      <p className="text-xs text-muted-foreground text-center">
        Siparişiniz kaydedilecek ve tasarım süreci başlayacaktır.
      </p>
    </Card>
  );
}
