import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Star, Check, Trash2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

interface Review {
  id: number;
  name: string;
  email?: string;
  rating: number;
  title?: string;
  comment: string;
  isApproved: boolean;
  createdAt: Date;
}

export default function ReviewManagement() {
  const [filter, setFilter] = useState<"pending" | "approved" | "all">("pending");
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  // Queries
  const pendingReviewsQuery = trpc.reviews.getPending.useQuery();
  const approvedReviewsQuery = trpc.reviews.getApproved.useQuery({ limit: 100, offset: 0 });

  // Mutations
  const approveMutation = trpc.reviews.approve.useMutation({
    onSuccess: () => {
      toast.success("Yorum onaylandı!");
      pendingReviewsQuery.refetch();
      approvedReviewsQuery.refetch();
    },
    onError: () => {
      toast.error("Yorum onaylanırken hata oluştu");
    },
  });

  const deleteMutation = trpc.reviews.delete.useMutation({
    onSuccess: () => {
      toast.success("Yorum silindi!");
      setDeleteConfirm(null);
      pendingReviewsQuery.refetch();
      approvedReviewsQuery.refetch();
    },
    onError: () => {
      toast.error("Yorum silinirken hata oluştu");
    },
  });

  // Get reviews based on filter
  const getReviews = (): Review[] => {
    if (filter === "pending") {
      return (pendingReviewsQuery.data || []) as Review[];
    } else if (filter === "approved") {
      return (approvedReviewsQuery.data || []) as Review[];
    } else {
      const pending = (pendingReviewsQuery.data || []) as Review[];
      const approved = (approvedReviewsQuery.data || []) as Review[];
      return [...pending, ...approved];
    }
  };

  const reviews = getReviews();
  const isLoading = pendingReviewsQuery.isLoading || approvedReviewsQuery.isLoading;

  return (
    <Card className="p-8 space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
          Müşteri Yorumları Yönetimi
        </h2>
        <p className="text-muted-foreground">
          Gelen yorumları onaylayın veya silin
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 border-b border-border">
        <button
          onClick={() => setFilter("pending")}
          className={`px-4 py-2 font-medium transition-colors ${
            filter === "pending"
              ? "border-b-2 border-accent text-accent"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          Beklemede ({pendingReviewsQuery.data?.length || 0})
        </button>
        <button
          onClick={() => setFilter("approved")}
          className={`px-4 py-2 font-medium transition-colors ${
            filter === "approved"
              ? "border-b-2 border-accent text-accent"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          Onaylı ({approvedReviewsQuery.data?.length || 0})
        </button>
        <button
          onClick={() => setFilter("all")}
          className={`px-4 py-2 font-medium transition-colors ${
            filter === "all"
              ? "border-b-2 border-accent text-accent"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          Tümü
        </button>
      </div>

      {/* Reviews List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">
            Yükleniyor...
          </div>
        ) : reviews.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>Yorum bulunamadı</p>
          </div>
        ) : (
          reviews.map((review) => (
            <div
              key={review.id}
              className={`p-6 rounded-lg border-2 transition-colors ${
                review.isApproved
                  ? "border-green-200 bg-green-50"
                  : "border-yellow-200 bg-yellow-50"
              }`}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-semibold text-foreground">{review.name}</h3>
                    {review.isApproved && (
                      <span className="text-xs bg-green-500 text-white px-2 py-1 rounded">
                        Onaylı
                      </span>
                    )}
                  </div>
                  {review.email && (
                    <p className="text-sm text-muted-foreground">{review.email}</p>
                  )}
                </div>
                <div className="text-sm text-muted-foreground">
                  {new Date(review.createdAt).toLocaleDateString("tr-TR")}
                </div>
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < review.rating
                        ? "fill-accent text-accent"
                        : "text-muted-foreground"
                    }`}
                  />
                ))}
              </div>

              {/* Title and Comment */}
              {review.title && (
                <p className="font-semibold text-foreground mb-2">{review.title}</p>
              )}
              <p className="text-muted-foreground mb-4">{review.comment}</p>

              {/* Actions */}
              <div className="flex gap-2">
                {!review.isApproved && (
                  <Button
                    onClick={() => approveMutation.mutate({ id: review.id })}
                    disabled={approveMutation.isPending}
                    className="bg-green-500 hover:bg-green-600 text-white flex items-center gap-2"
                  >
                    <Check className="w-4 h-4" />
                    Onayla
                  </Button>
                )}

                {deleteConfirm === review.id ? (
                  <div className="flex gap-2 flex-1">
                    <Button
                      onClick={() => deleteMutation.mutate({ id: review.id })}
                      disabled={deleteMutation.isPending}
                      className="bg-destructive hover:bg-destructive/80 text-white flex-1"
                    >
                      Evet, Sil
                    </Button>
                    <Button
                      onClick={() => setDeleteConfirm(null)}
                      variant="outline"
                      className="flex-1"
                    >
                      İptal
                    </Button>
                  </div>
                ) : (
                  <Button
                    onClick={() => setDeleteConfirm(review.id)}
                    variant="outline"
                    className="border-destructive text-destructive hover:bg-destructive/10 flex items-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    Sil
                  </Button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </Card>
  );
}
