import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Star } from "lucide-react";
import { toast } from "sonner";

interface ReviewFormProps {
  onSuccess?: () => void;
  orderId?: number;
}

export default function ReviewForm({ onSuccess, orderId }: ReviewFormProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState("");
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const createReviewMutation = trpc.reviews.create.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      toast.error("Lütfen adınızı girin");
      return;
    }

    if (comment.trim().length < 10) {
      toast.error("Yorum en az 10 karakter olmalıdır");
      return;
    }

    setIsSubmitting(true);

    try {
      await createReviewMutation.mutateAsync({
        name,
        email: email || undefined,
        rating,
        title: title || undefined,
        comment,
        orderId,
      });

      toast.success("Yorumunuz başarıyla gönderildi! Onay beklemektedir.");
      
      // Reset form
      setName("");
      setEmail("");
      setRating(5);
      setTitle("");
      setComment("");

      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error("Error submitting review:", error);
      toast.error("Yorum gönderilirken hata oluştu");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="p-8 space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
          Yorum Yazın
        </h2>
        <p className="text-muted-foreground">
          Kalpten Kareler hakkında deneyiminizi paylaşın
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Name */}
        <div className="space-y-2">
          <label className="text-sm font-semibold">
            Adınız <span className="text-destructive">*</span>
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Adınız"
            className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
            required
          />
        </div>

        {/* Email */}
        <div className="space-y-2">
          <label className="text-sm font-semibold">E-posta (İsteğe Bağlı)</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="ornek@email.com"
            className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
          />
        </div>

        {/* Rating */}
        <div className="space-y-2">
          <label className="text-sm font-semibold">
            Puan <span className="text-destructive">*</span>
          </label>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                className="transition-transform hover:scale-110"
              >
                <Star
                  className={`w-8 h-8 ${
                    star <= rating
                      ? "fill-accent text-accent"
                      : "text-muted-foreground"
                  }`}
                />
              </button>
            ))}
          </div>
          <p className="text-sm text-muted-foreground">
            {rating === 1 && "Çok kötü"}
            {rating === 2 && "Kötü"}
            {rating === 3 && "Orta"}
            {rating === 4 && "İyi"}
            {rating === 5 && "Çok iyi"}
          </p>
        </div>

        {/* Title */}
        <div className="space-y-2">
          <label className="text-sm font-semibold">Başlık (İsteğe Bağlı)</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Örn: Harika bir ürün!"
            className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
          />
        </div>

        {/* Comment */}
        <div className="space-y-2">
          <label className="text-sm font-semibold">
            Yorum <span className="text-destructive">*</span>
          </label>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Deneyiminizi detaylı olarak anlatın..."
            rows={5}
            className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent resize-none"
            required
          />
          <p className="text-xs text-muted-foreground">
            {comment.length}/500 karakter
          </p>
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-accent hover:bg-accent/80"
        >
          {isSubmitting ? "Gönderiliyor..." : "Yorumu Gönder"}
        </Button>

        <p className="text-xs text-muted-foreground text-center">
          Yorumunuz yayınlanmadan önce yönetici tarafından onaylanacaktır.
        </p>
      </form>
    </Card>
  );
}
